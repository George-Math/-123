package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.LicenseStatus
import com.example.data.model.VehicleLicense
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("رخصتي", appName)
    }

    @Test
    fun `vehicle license expiry status calculates accurately`() {
        val now = 1000000000000L
        val day = TimeUnit.DAYS.toMillis(1)

        val expiredVehicle = VehicleLicense(
            makeAndModel = "Toyota Corolla",
            manufactureYear = 2020,
            plateNumber = "س ر ج 123",
            licenseExpiryDateMillis = now - (5 * day)
        )
        assertEquals(LicenseStatus.EXPIRED, expiredVehicle.getLicenseStatus(now))
        assertTrue(expiredVehicle.isDueForRenewalWorkflow(now))

        val expiringVehicle = VehicleLicense(
            makeAndModel = "Hyundai Tucson",
            manufactureYear = 2022,
            plateNumber = "ق د ن 456",
            licenseExpiryDateMillis = now + (15 * day)
        )
        assertEquals(LicenseStatus.EXPIRING_SOON, expiringVehicle.getLicenseStatus(now))
        assertTrue(expiringVehicle.isDueForRenewalWorkflow(now))

        val validVehicle = VehicleLicense(
            makeAndModel = "Kia Sportage",
            manufactureYear = 2023,
            plateNumber = "ب ط و 789",
            licenseExpiryDateMillis = now + (120 * day)
        )
        assertEquals(LicenseStatus.VALID, validVehicle.getLicenseStatus(now))
    }

    @Test
    fun `refrigerated truck requires five procedure steps including health certificate`() {
        val normalCar = VehicleLicense(
            makeAndModel = "Corolla",
            manufactureYear = 2022,
            plateNumber = "123",
            licenseExpiryDateMillis = 0L,
            isRefrigeratedTruck = false
        )
        assertEquals(4, normalCar.getTotalProcedureSteps())

        val refrigeratedTruck = VehicleLicense(
            makeAndModel = "Isuzu Refrigerator",
            manufactureYear = 2023,
            plateNumber = "456",
            licenseExpiryDateMillis = 0L,
            isRefrigeratedTruck = true
        )
        assertEquals(5, refrigeratedTruck.getTotalProcedureSteps())
    }

    @Test
    fun `vehicle code and insurance details are properly stored`() {
        val vehicle = VehicleLicense(
            vehicleCode = "CAR-777",
            makeAndModel = "Corolla",
            manufactureYear = 2022,
            plateNumber = "123",
            licenseExpiryDateMillis = 0L,
            vehicleInsuranceNumber = "INS-VEH-123",
            driverInsuranceNumber = "INS-DRV-456",
            hasAssignedDriver = true,
            driverName = "أحمد مصطفى"
        )
        assertEquals("CAR-777", vehicle.vehicleCode)
        assertEquals("INS-VEH-123", vehicle.vehicleInsuranceNumber)
        assertEquals("INS-DRV-456", vehicle.driverInsuranceNumber)
        assertTrue(vehicle.hasAssignedDriver)
        assertEquals("أحمد مصطفى", vehicle.driverName)
    }
}
