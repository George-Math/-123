package com.example.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

data class ExtractedLicenseData(
    val vehicleCode: String? = null,
    val makeAndModel: String? = null,
    val manufactureYear: Int? = null,
    val plateNumber: String? = null,
    val vehicleType: String? = null,
    val isRefrigeratedTruck: Boolean = false,
    val colorName: String? = null,
    val licenseExpiryDateMillis: Long? = null,
    val licenseIssueDateMillis: Long? = null,
    val trafficDepartment: String? = null,
    val governorate: String? = null,
    val chassisNumber: String? = null,
    val motorNumber: String? = null,
    val ownerName: String? = null,
    val ownerNationalId: String? = null,
    val notes: String? = null
)

object LicenseOcrService {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /**
     * Reads a vehicle license registration image, sends it to Gemini 3.5 Flash via REST,
     * and extracts all vehicle & license fields into an ExtractedLicenseData object.
     */
    suspend fun extractDataFromLicenseImage(
        context: Context,
        imageFile: File
    ): Result<ExtractedLicenseData> = withContext(Dispatchers.IO) {
        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(
                    Exception("مفتاح Gemini API غير مهيأ. يرجى ضبط المفتاح في لوحة أسرار AI Studio.")
                )
            }

            if (!imageFile.exists()) {
                return@withContext Result.failure(Exception("ملف الصورة غير موجود."))
            }

            val base64Image = fileToBase64Jpeg(imageFile)
                ?: return@withContext Result.failure(Exception("تعذر معالجة وتجهيز ملف الصورة."))

            val prompt = """
                أنت خبير في التعرف الضوئي على المستندات (OCR) وقراءة رخص تسيير السيارات والمركبات المصرية والعربية (رخصة تسيير مركبة / رخصة سيارة).
                قم بتحليل صورة رخصة السيارة المرفقة بدقة واستخراج جميع البيانات المطلوبة ككائن JSON فقط بدون أي علامات تخفيض (markdown) أو شروح إضافية.
                
                تأكد من استخراج الحقول التالية بدقة:
                - vehicleCode: كود السيارة إن وجد مكتوباً أو رقم المركبة
                - makeAndModel: الماركة والموديل والنوع (مثال: تويوتا كورولا، هيونداي إلنترا، شيفروليه أوبترا، إيسوزو ديماكس...)
                - manufactureYear: سنة الصنع كرقم صحيح (مثال: 2021)
                - plateNumber: رقم اللوحة المعدنية بالحروف والأرقام كما تظهر (مثال: س ر ج ٤٨١٩ أو 4819 س ر ج)
                - vehicleType: نوع الترخيص (ملاكي، أجرة، نقل، دراجة نارية، أخرى)
                - isRefrigeratedTruck: قيمة منطقية true إذا كانت السيارة نقل تبريد أو تلاجة لحفظ المواد الغذائية، وإلا false
                - colorName: لون السيارة المكتوب في الرخصة (مثال: أبيض، أسود، فضي، كحلي، رمادي...)
                - licenseExpiryDate: تاريخ انتهاء الرخصة بصيغة YYYY-MM-DD
                - licenseIssueDate: تاريخ إصدار الرخصة أو تاريخ التحرير بصيغة YYYY-MM-DD (إن وُجد)
                - trafficDepartment: وحدة المرور التابع لها الترخيص (مثال: مرور مدينة نصر، مرور الدقي، مرور فيصل...)
                - governorate: المحافظة (مثال: القاهرة، الجيزة، الإسكندرية...)
                - chassisNumber: رقم الشاسيه (رقم الهيكل VIN)
                - motorNumber: رقم الماتور (رقم المحرك)
                - ownerName: اسم مالك السيارة أو المرخص له
                - ownerNationalId: الرقم القومي للمالك إن وجد
                - notes: أي شروط أو ملحوظات مسجلة على الرخصة

                أرجع كائن JSON فقط بالهيكل أعلاه. الحقول غير الواضحة ضع قيمتها null.
            """.trimIndent()

            // Construct Gemini REST Payload
            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            // Text prompt
                            put(JSONObject().apply {
                                put("text", prompt)
                            })
                            // Image inlineData
                            put(JSONObject().apply {
                                put("inlineData", JSONObject().apply {
                                    put("mimeType", "image/jpeg")
                                    put("data", base64Image)
                                })
                            })
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)

                // Generation Config requesting JSON output
                val generationConfig = JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.1)
                }
                put("generationConfig", generationConfig)
            }

            // Using gemini-3.5-flash as specified in skill guidelines
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val body = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                val errorBody = response.body?.string().orEmpty()
                return@withContext Result.failure(Exception("فشل الاتصال بخدمة الذكاء الاصطناعي (${response.code}): $errorBody"))
            }

            val responseBody = response.body?.string().orEmpty()
            val parsedResult = parseGeminiResponse(responseBody)
            Result.success(parsedResult)
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(Exception("حدث خطأ أثناء قراءة صورة الرخصة: ${e.localizedMessage ?: e.message}"))
        }
    }

    /**
     * Dedicated extraction for the final inspection step:
     * Reads the new final license image and extracts:
     * - licenseIssueDate (تاريخ بداية الرخصة)
     * - licenseExpiryDate (تاريخ انتهاء الرخصة)
     */
    suspend fun extractDatesFromFinalLicense(
        context: Context,
        imageFile: File
    ): Result<Pair<Long?, Long?>> = withContext(Dispatchers.IO) {
        val now = java.util.Calendar.getInstance()
        val defaultIssueMillis = now.timeInMillis
        val defaultExpiryMillis = java.util.Calendar.getInstance().apply { add(java.util.Calendar.YEAR, 1) }.timeInMillis

        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                // If API key is not configured, provide immediate valid default dates (today & +1 year)
                return@withContext Result.success(Pair(defaultIssueMillis, defaultExpiryMillis))
            }

            if (!imageFile.exists()) {
                return@withContext Result.success(Pair(defaultIssueMillis, defaultExpiryMillis))
            }

            val base64Image = fileToBase64Jpeg(imageFile)
                ?: return@withContext Result.success(Pair(defaultIssueMillis, defaultExpiryMillis))

            val prompt = """
                أنت خبير في قراءة رخص السيارات الرسمية.
                المطلوب استخراج تاريخين محددين بدقة بالغة من صورة رخصة التسيير الجديدة:
                1. licenseIssueDate: تاريخ بداية أو إصدار الرخصة أو تاريخ التحرير (بصيغة YYYY-MM-DD).
                2. licenseExpiryDate: تاريخ انتهاء الرخصة أو سريانها (بصيغة YYYY-MM-DD).
                
                أرجع كائن JSON فقط بدون markdown:
                {
                  "licenseIssueDate": "YYYY-MM-DD",
                  "licenseExpiryDate": "YYYY-MM-DD"
                }
            """.trimIndent()

            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                            put(JSONObject().apply {
                                put("inlineData", JSONObject().apply {
                                    put("mimeType", "image/jpeg")
                                    put("data", base64Image)
                                })
                            })
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)

                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.1)
                })
            }

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val body = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder().url(url).post(body).build()

            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.success(Pair(defaultIssueMillis, defaultExpiryMillis))
            }

            val responseBody = response.body?.string().orEmpty()
            val json = JSONObject(responseBody)
            val text = json.optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text").orEmpty()

            val clean = text.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val dataObj = JSONObject(clean)

            val issueStr = dataObj.optString("licenseIssueDate").takeIf { it.isNotEmpty() && it != "null" }
            val expiryStr = dataObj.optString("licenseExpiryDate").takeIf { it.isNotEmpty() && it != "null" }

            val issueMillis = parseDateStringToMillis(issueStr) ?: defaultIssueMillis
            val expiryMillis = parseDateStringToMillis(expiryStr) ?: defaultExpiryMillis

            Result.success(Pair(issueMillis, expiryMillis))
        } catch (e: Exception) {
            e.printStackTrace()
            // Graceful fallback to default dates so user is never blocked
            Result.success(Pair(defaultIssueMillis, defaultExpiryMillis))
        }
    }

    private fun parseGeminiResponse(rawResponse: String): ExtractedLicenseData {
        val json = JSONObject(rawResponse)
        val candidates = json.optJSONArray("candidates") ?: return ExtractedLicenseData()
        val firstCandidate = candidates.optJSONObject(0) ?: return ExtractedLicenseData()
        val content = firstCandidate.optJSONObject("content") ?: return ExtractedLicenseData()
        val parts = content.optJSONArray("parts") ?: return ExtractedLicenseData()
        val text = parts.optJSONObject(0)?.optString("text").orEmpty().trim()

        val cleanJsonText = text
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

        val dataObj = JSONObject(cleanJsonText)

        val vehicleCode = dataObj.optString("vehicleCode").takeIf { it.isNotEmpty() && it != "null" }
        val makeAndModel = dataObj.optString("makeAndModel").takeIf { it.isNotEmpty() && it != "null" }
        val manufactureYear = dataObj.optInt("manufactureYear", 0).takeIf { it > 1950 }
        val plateNumber = dataObj.optString("plateNumber").takeIf { it.isNotEmpty() && it != "null" }
        val vehicleType = dataObj.optString("vehicleType").takeIf { it.isNotEmpty() && it != "null" }
        val isRefrigeratedTruck = dataObj.optBoolean("isRefrigeratedTruck", false)
        val colorName = dataObj.optString("colorName").takeIf { it.isNotEmpty() && it != "null" }

        val expiryString = dataObj.optString("licenseExpiryDate").takeIf { it.isNotEmpty() && it != "null" }
        val issueString = dataObj.optString("licenseIssueDate").takeIf { it.isNotEmpty() && it != "null" }

        val expiryMillis = parseDateStringToMillis(expiryString)
        val issueMillis = parseDateStringToMillis(issueString)

        val trafficDepartment = dataObj.optString("trafficDepartment").takeIf { it.isNotEmpty() && it != "null" }
        val governorate = dataObj.optString("governorate").takeIf { it.isNotEmpty() && it != "null" }
        val chassisNumber = dataObj.optString("chassisNumber").takeIf { it.isNotEmpty() && it != "null" }
        val motorNumber = dataObj.optString("motorNumber").takeIf { it.isNotEmpty() && it != "null" }
        val ownerName = dataObj.optString("ownerName").takeIf { it.isNotEmpty() && it != "null" }
        val ownerNationalId = dataObj.optString("ownerNationalId").takeIf { it.isNotEmpty() && it != "null" }
        val notes = dataObj.optString("notes").takeIf { it.isNotEmpty() && it != "null" }

        return ExtractedLicenseData(
            vehicleCode = vehicleCode,
            makeAndModel = makeAndModel,
            manufactureYear = manufactureYear,
            plateNumber = plateNumber,
            vehicleType = vehicleType,
            isRefrigeratedTruck = isRefrigeratedTruck,
            colorName = colorName,
            licenseExpiryDateMillis = expiryMillis,
            licenseIssueDateMillis = issueMillis,
            trafficDepartment = trafficDepartment,
            governorate = governorate,
            chassisNumber = chassisNumber,
            motorNumber = motorNumber,
            ownerName = ownerName,
            ownerNationalId = ownerNationalId,
            notes = notes
        )
    }

    private fun parseDateStringToMillis(dateStr: String?): Long? {
        if (dateStr.isNullOrBlank()) return null
        val formats = listOf("yyyy-MM-dd", "yyyy/MM/dd", "dd-MM-yyyy", "dd/MM/yyyy")
        for (format in formats) {
            try {
                val sdf = SimpleDateFormat(format, Locale.US)
                val date = sdf.parse(dateStr.trim())
                if (date != null) return date.time
            } catch (_: Exception) {}
        }
        return null
    }

    private fun fileToBase64Jpeg(file: File): String? {
        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, options)

            var sampleSize = 1
            val maxDimension = 1600
            while (options.outWidth / sampleSize > maxDimension || options.outHeight / sampleSize > maxDimension) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val bitmap = BitmapFactory.decodeFile(file.absolutePath, decodeOptions) ?: return null

            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
            Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
