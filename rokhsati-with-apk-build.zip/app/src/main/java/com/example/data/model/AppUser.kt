package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole {
    USER,
    ADMIN
}

@Entity(tableName = "app_users")
data class AppUser(
    @PrimaryKey
    val username: String,
    val password: String,
    val role: UserRole = UserRole.USER,
    val displayName: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)
