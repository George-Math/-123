package com.example.data.repository

import com.example.data.db.VehicleDao
import com.example.data.model.VehicleLicense
import kotlinx.coroutines.flow.Flow

class VehicleRepository(private val vehicleDao: VehicleDao) {

    val allVehicles: Flow<List<VehicleLicense>> = vehicleDao.getAllVehicles()

    fun getVehicleById(id: Long): Flow<VehicleLicense?> = vehicleDao.getVehicleById(id)

    suspend fun insertVehicle(vehicle: VehicleLicense): Long = vehicleDao.insertVehicle(vehicle)

    suspend fun insertAll(vehicles: List<VehicleLicense>) = vehicleDao.insertAll(vehicles)

    suspend fun updateVehicle(vehicle: VehicleLicense) = vehicleDao.updateVehicle(vehicle)

    suspend fun deleteVehicle(vehicle: VehicleLicense) = vehicleDao.deleteVehicle(vehicle)

    suspend fun deleteVehicleById(id: Long) = vehicleDao.deleteVehicleById(id)

    suspend fun clearAll() = vehicleDao.clearAll()
}
