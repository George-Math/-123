package com.example.data.repository

import com.example.data.db.UserDao
import com.example.data.model.AppUser
import com.example.data.model.UserRole
import kotlinx.coroutines.flow.Flow

class UserRepository(private val userDao: UserDao) {

    val allUsers: Flow<List<AppUser>> = userDao.getAllUsers()

    suspend fun seedDefaults() {
        // Seed default normal user: 1 / 1507
        if (userDao.getUserByUsername("1") == null) {
            userDao.insertUser(
                AppUser(
                    username = "1",
                    password = "1507",
                    role = UserRole.USER,
                    displayName = "المستخدم الأساسي"
                )
            )
        }
        // Seed admin user: 1507 / 0311
        if (userDao.getUserByUsername("1507") == null) {
            userDao.insertUser(
                AppUser(
                    username = "1507",
                    password = "0311",
                    role = UserRole.ADMIN,
                    displayName = "مسئول النظام"
                )
            )
        }
    }

    suspend fun authenticateUser(username: String, password: String): AppUser? {
        val trimmedUser = username.trim()
        val trimmedPass = password.trim()

        // Hardcoded safety fallback for default normal user
        if (trimmedUser == "1" && trimmedPass == "1507") {
            return AppUser(
                username = "1",
                password = "1507",
                role = UserRole.USER,
                displayName = "المستخدم الأساسي"
            )
        }

        // Hardcoded safety fallback for admin user
        if (trimmedUser == "1507" && trimmedPass == "0311") {
            return AppUser(
                username = "1507",
                password = "0311",
                role = UserRole.ADMIN,
                displayName = "مسئول النظام"
            )
        }

        val dbUser = userDao.getUserByUsername(trimmedUser)
        return if (dbUser != null && dbUser.password == trimmedPass) {
            dbUser
        } else {
            null
        }
    }

    suspend fun authenticateAdmin(username: String, password: String): AppUser? {
        val trimmedUser = username.trim()
        val trimmedPass = password.trim()

        if (trimmedUser == "1507" && trimmedPass == "0311") {
            return AppUser(
                username = "1507",
                password = "0311",
                role = UserRole.ADMIN,
                displayName = "مسئول النظام"
            )
        }

        val dbUser = userDao.getUserByUsername(trimmedUser)
        return if (dbUser != null && dbUser.role == UserRole.ADMIN && dbUser.password == trimmedPass) {
            dbUser
        } else {
            null
        }
    }

    suspend fun addUser(user: AppUser): Result<Unit> {
        val trimmed = user.username.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("اسم المستخدم لا يمكن أن يكون فارغاً"))
        }
        if (user.password.trim().isEmpty()) {
            return Result.failure(IllegalArgumentException("كلمة المرور لا يمكن أن تكون فارغة"))
        }
        val existing = userDao.getUserByUsername(trimmed)
        if (existing != null && trimmed != "1" && trimmed != "1507") {
            return Result.failure(IllegalArgumentException("اسم المستخدم مسجل بالفعل، يرجى اختيار اسم آخر"))
        }
        userDao.insertUser(user.copy(username = trimmed, password = user.password.trim()))
        return Result.success(Unit)
    }

    suspend fun deleteUser(username: String) {
        // Prevent deleting the primary user or admin
        if (username != "1" && username != "1507") {
            userDao.deleteUserByUsername(username)
        }
    }
}
