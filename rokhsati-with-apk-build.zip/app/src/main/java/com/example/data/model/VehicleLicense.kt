package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vehicles")
data class VehicleLicense(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val vehicleCode: String = "",         // كود السيارة الداخلي e.g. CAR-101
    val makeAndModel: String,            // e.g. تويوتا كورولا
    val manufactureYear: Int,            // e.g. 2022
    val plateNumber: String,             // e.g. ق د س ١٢٣٤
    val vehicleType: String = "ملاكي",    // ملاكي، أجرة، نقل، دراجة نارية، أخرى
    val isRefrigeratedTruck: Boolean = false, // سيارة نقل تبريد / تلاجة (تتطلب فحص وزارة الصحة)
    val colorName: String = "أبيض",       // أبيض، أسود، فضي، كحلي، أحمر، رمادي
    val colorHex: Long = 0xFF2563EB,     // Color code for display accent
    val licenseExpiryDateMillis: Long,   // تاريخ انتهاء الرخصة
    val licenseIssueDateMillis: Long = 0,// تاريخ إصدار الرخصة
    val trafficDepartment: String = "",  // وحدة المرور e.g. مرور مدينة نصر
    val governorate: String = "",        // المحافظة e.g. القاهرة
    val chassisNumber: String = "",      // رقم الشاسيه (VIN)
    val motorNumber: String = "",        // رقم المحرك (الماتور)
    val inspectionExpiryMillis: Long = 0,// تاريخ الفحص الفني الدوري
    val insuranceExpiryMillis: Long = 0, // تاريخ انتهاء التأمين الإجباري
    val estimatedRenewalCost: Double = 0.0, // رسوم التجديد التقديرية
    val ownerName: String = "",          // اسم المالك
    val ownerNationalId: String = "",    // الرقم القومي
    val notes: String = "",              // ملاحظات إضافية

    // 1. صورة رخصة التسيير (محفوظة محلياً في الذاكرة الداخلية)
    val licenseImagePath: String? = null,

    // 2. مستندات وإجراءات تجديد الرخصة (محفوظة محلياً في الذاكرة الداخلية)
    // الخطوة 1: شهادة بيانات من المرور للتأمينات والضرائب
    val trafficDataCertPath: String? = null,
    val trafficDataCertCompleted: Boolean = false,

    // الخطوة 2: شهادة الضرائب (سداد / براءة ذمة)
    val taxCertPath: String? = null,
    val taxCertCompleted: Boolean = false,

    // الخطوة 3: شهادة التأمينات الاجتماعية وبيانات السائق
    val insuranceCertPath: String? = null,
    val insuranceCertCompleted: Boolean = false,
    val hasAssignedDriver: Boolean = false,              // ربط سائق بالسيارة
    val driverName: String = "",                         // اسم السائق
    val vehicleInsuranceNumber: String = "",             // الرقم التأميني للسيارة
    val driverInsuranceNumber: String = "",              // الرقم التأميني للسائق
    val driverNationalIdImagePath: String? = null,       // صورة البطاقة الشخصية للسائق
    val driverLicenseImagePath: String? = null,          // صورة رخصة قيادة السائق

    // الخطوة 4: فحص وزارة الصحة وشهادة صلاحية التلاجة (خاصة بسيارات التلاجة)
    val healthCertPath: String? = null,
    val healthCertCompleted: Boolean = false,

    // الخطوة 5: الفحص الفني النهائي للمرور واستلام الرخصة الجديدة
    val finalInspectionCertPath: String? = null,
    val finalInspectionCompleted: Boolean = false,

    val createdAtMillis: Long = System.currentTimeMillis()
) {
    /**
     * Calculate days remaining until license expiration.
     * Negative values indicate expired license.
     */
    fun getDaysUntilExpiry(currentTimeMillis: Long = System.currentTimeMillis()): Int {
        val diff = licenseExpiryDateMillis - currentTimeMillis
        return (diff / (1000 * 60 * 60 * 24)).toInt()
    }

    fun getLicenseStatus(currentTimeMillis: Long = System.currentTimeMillis()): LicenseStatus {
        val days = getDaysUntilExpiry(currentTimeMillis)
        return when {
            days < 0 -> LicenseStatus.EXPIRED
            days <= 30 -> LicenseStatus.EXPIRING_SOON
            else -> LicenseStatus.VALID
        }
    }

    /**
     * Whether the vehicle is within 30 days of expiry or expired,
     * triggering the renewal reminder workflow.
     */
    fun isDueForRenewalWorkflow(currentTimeMillis: Long = System.currentTimeMillis()): Boolean {
        return getDaysUntilExpiry(currentTimeMillis) <= 30
    }

    /**
     * Total steps for renewal procedure (5 if refrigerated truck, 4 if normal vehicle).
     */
    fun getTotalProcedureSteps(): Int {
        return if (isRefrigeratedTruck) 5 else 4
    }

    /**
     * Completed steps count.
     */
    fun getCompletedProcedureSteps(): Int {
        var completed = 0
        if (trafficDataCertCompleted) completed++
        if (taxCertCompleted) completed++
        if (insuranceCertCompleted) completed++
        if (isRefrigeratedTruck && healthCertCompleted) completed++
        if (finalInspectionCompleted) completed++
        return completed
    }

    fun areProceduresFullyCompleted(): Boolean {
        return getCompletedProcedureSteps() == getTotalProcedureSteps()
    }
}

enum class LicenseStatus(val arabicLabel: String) {
    VALID("سارية"),
    EXPIRING_SOON("تنتهي قريباً"),
    EXPIRED("منتهية")
}
