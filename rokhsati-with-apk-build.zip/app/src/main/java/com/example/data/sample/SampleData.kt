package com.example.data.sample

import com.example.data.model.VehicleLicense
import java.util.concurrent.TimeUnit

object SampleData {
    fun getSampleVehicles(): List<VehicleLicense> {
        val now = System.currentTimeMillis()
        val day = TimeUnit.DAYS.toMillis(1)

        return listOf(
            VehicleLicense(
                id = 1,
                vehicleCode = "CAR-101",
                makeAndModel = "تويوتا كورولا",
                manufactureYear = 2022,
                plateNumber = "س ر ج ٤٨١٩",
                vehicleType = "ملاكي",
                colorName = "فضي ميتاليك",
                colorHex = 0xFF94A3B8,
                licenseExpiryDateMillis = now + (18 * day), // Expiring in 18 days
                licenseIssueDateMillis = now - (347 * day),
                trafficDepartment = "مرور مدينة نصر",
                governorate = "القاهرة",
                chassisNumber = "JTDBR32E602981440",
                motorNumber = "1ZR-7489211",
                inspectionExpiryMillis = now + (200 * day),
                insuranceExpiryMillis = now + (18 * day),
                vehicleInsuranceNumber = "940218",
                driverInsuranceNumber = "184092",
                hasAssignedDriver = true,
                driverName = "محمود عادل إبراهيم",
                estimatedRenewalCost = 2150.0,
                ownerName = "أحمد محمد محمود",
                ownerNationalId = "29410150102345",
                notes = "الرخصة قاربت على الانتهاء، مطلوب شهادة مخالفات وبراءة ذمة قبل التوجه للمرور."
            ),
            VehicleLicense(
                id = 2,
                vehicleCode = "TRK-204",
                makeAndModel = "شيفروليه ديماكس تلاجة",
                manufactureYear = 2023,
                plateNumber = "ق د ن ٧٢٥٣",
                vehicleType = "نقل",
                isRefrigeratedTruck = true,
                colorName = "أبيض",
                colorHex = 0xFFE2E8F0,
                licenseExpiryDateMillis = now - (7 * day), // Expired 7 days ago
                licenseIssueDateMillis = now - (372 * day),
                trafficDepartment = "مرور الدقي",
                governorate = "الجيزة",
                chassisNumber = "KMHHU81BDNU849201",
                motorNumber = "G4FP-194022",
                inspectionExpiryMillis = now + (350 * day),
                insuranceExpiryMillis = now - (7 * day),
                vehicleInsuranceNumber = "551940",
                driverInsuranceNumber = "772019",
                hasAssignedDriver = true,
                driverName = "علي كمال مصطفى",
                estimatedRenewalCost = 3400.0,
                ownerName = "شركة النيل للتبريد",
                ownerNationalId = "29805212104598",
                notes = "سيارة تبريد وتلاجة لحفظ ونقل المواد الغذائية تتطلب فحص صلاحية وزارة الصحة."
            ),
            VehicleLicense(
                id = 3,
                vehicleCode = "CAR-305",
                makeAndModel = "كيا سبورتاج",
                manufactureYear = 2021,
                plateNumber = "ب ط و ١٥٢٩",
                vehicleType = "ملاكي",
                colorName = "أبيض لؤلؤي",
                colorHex = 0xFFE2E8F0,
                licenseExpiryDateMillis = now + (240 * day), // Valid for 8 months
                licenseIssueDateMillis = now - (125 * day),
                trafficDepartment = "مرور الشروق",
                governorate = "القاهرة",
                chassisNumber = "KNAFK4A28M7619203",
                motorNumber = "G4FJ-883901",
                inspectionExpiryMillis = now + (240 * day),
                insuranceExpiryMillis = now + (240 * day),
                vehicleInsuranceNumber = "381044",
                driverInsuranceNumber = "490122",
                estimatedRenewalCost = 2800.0,
                ownerName = "مروان كريم يوسف",
                ownerNationalId = "28912091403211",
                notes = "سارية المفعول - الفحص القادم مع التجديد."
            ),
            VehicleLicense(
                id = 4,
                vehicleCode = "CAR-409",
                makeAndModel = "مرسيدس بنز C200",
                manufactureYear = 2024,
                plateNumber = "م هـ س ٩٩٩٩",
                vehicleType = "ملاكي",
                colorName = "كحلي داكن",
                colorHex = 0xFF1E3A8A,
                licenseExpiryDateMillis = now + (580 * day), // Valid for ~1.5 years
                licenseIssueDateMillis = now - (150 * day),
                trafficDepartment = "مرور التجمع الخامس",
                governorate = "القاهرة",
                chassisNumber = "W1K2060421F384910",
                motorNumber = "M254-920411",
                inspectionExpiryMillis = now + (945 * day),
                insuranceExpiryMillis = now + (580 * day),
                vehicleInsuranceNumber = "882190",
                driverInsuranceNumber = "",
                estimatedRenewalCost = 5200.0,
                ownerName = "م. خالد عبد الرحمن",
                ownerNationalId = "28503140101923",
                notes = "ترخيص 3 سنوات معفى من الفحص الفني للعامين الأولين."
            )
        )
    }
}
