package com.example.utils

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

object FileStorageUtils {

    /**
     * Copies an image selected from the Photo Picker to the app's private internal storage.
     * Returns the absolute path of the saved local file.
     */
    fun saveImageToInternalStorage(context: Context, sourceUri: Uri, prefix: String = "doc"): String? {
        return try {
            val docsDir = File(context.filesDir, "vehicle_documents")
            if (!docsDir.exists()) {
                docsDir.mkdirs()
            }

            val fileName = "${prefix}_${System.currentTimeMillis()}.jpg"
            val destinationFile = File(docsDir, fileName)

            val inputStream: InputStream? = context.contentResolver.openInputStream(sourceUri)
            val outputStream = FileOutputStream(destinationFile)

            inputStream?.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }

            destinationFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Deletes a file from internal storage if it exists.
     */
    fun deleteInternalFile(path: String?): Boolean {
        if (path.isNullOrEmpty()) return false
        return try {
            val file = File(path)
            if (file.exists()) file.delete() else false
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
