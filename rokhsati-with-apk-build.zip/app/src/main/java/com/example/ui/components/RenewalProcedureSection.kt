package com.example.ui.components

import android.app.DatePickerDialog
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveEta
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.NotificationImportant
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ai.LicenseOcrService
import com.example.data.model.VehicleLicense
import com.example.ui.theme.StatusExpired
import com.example.ui.theme.StatusExpiredContainer
import com.example.ui.theme.StatusValid
import com.example.ui.theme.StatusValidContainer
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningContainer
import com.example.utils.FileStorageUtils
import kotlinx.coroutines.launch
import java.io.File
import java.util.Calendar

@Composable
fun RenewalProcedureSection(
    vehicle: VehicleLicense,
    onUpdateVehicle: (VehicleLicense) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val isDue = vehicle.isDueForRenewalWorkflow()
    val completedSteps = vehicle.getCompletedProcedureSteps()
    val totalSteps = vehicle.getTotalProcedureSteps()
    val progress = completedSteps.toFloat() / totalSteps.coerceAtLeast(1)

    // State for Step 5 Final license OCR reading
    var isReadingFinalLicenseDates by remember { mutableStateOf(false) }
    var detectedNewIssueDate by remember(vehicle.finalInspectionCertPath) {
        mutableLongStateOf(
            if (vehicle.licenseIssueDateMillis > 0) vehicle.licenseIssueDateMillis else System.currentTimeMillis()
        )
    }
    var detectedNewExpiryDate by remember(vehicle.finalInspectionCertPath) {
        mutableLongStateOf(
            if (vehicle.licenseExpiryDateMillis > System.currentTimeMillis()) vehicle.licenseExpiryDateMillis
            else Calendar.getInstance().apply { add(Calendar.YEAR, 1) }.timeInMillis
        )
    }
    var datesDetectedSuccessfully by remember { mutableStateOf(false) }

    // Photo pickers for Driver National ID & Driver License in Step 3
    var viewingDocumentPath by remember { mutableStateOf<String?>(null) }
    var viewingDocumentTitle by remember { mutableStateOf("") }

    val driverIdPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val localPath = FileStorageUtils.saveImageToInternalStorage(context, uri, prefix = "driver_id")
            if (localPath != null) {
                onUpdateVehicle(vehicle.copy(driverNationalIdImagePath = localPath))
                Toast.makeText(context, "تم حفظ صورة بطاقة السائق في الهاتف", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val driverLicensePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val localPath = FileStorageUtils.saveImageToInternalStorage(context, uri, prefix = "driver_license")
            if (localPath != null) {
                onUpdateVehicle(vehicle.copy(driverLicenseImagePath = localPath))
                Toast.makeText(context, "تم حفظ صورة رخصة السائق في الهاتف", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Step 5: Final license picker that extracts start & end dates automatically
    val finalLicensePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val localPath = FileStorageUtils.saveImageToInternalStorage(context, uri, prefix = "final_new_license")
            if (localPath != null) {
                val updatedWithCert = vehicle.copy(finalInspectionCertPath = localPath)
                onUpdateVehicle(updatedWithCert)

                // Trigger automatic OCR reading of start & end dates!
                isReadingFinalLicenseDates = true
                coroutineScope.launch {
                    val result = LicenseOcrService.extractDatesFromFinalLicense(context, File(localPath))
                    isReadingFinalLicenseDates = false
                    result.onSuccess { (issueMillis, expiryMillis) ->
                        if (issueMillis != null) detectedNewIssueDate = issueMillis
                        if (expiryMillis != null) detectedNewExpiryDate = expiryMillis
                        datesDetectedSuccessfully = true
                        Toast.makeText(
                            context,
                            "تم استخراج تاريخ بداية ونهاية الرخصة الجديدة تلقائياً! يرجى التأكيد للاعتماد.",
                            Toast.LENGTH_LONG
                        ).show()
                    }.onFailure {
                        Toast.makeText(
                            context,
                            "تم حفظ صورة الرخصة. يمكنك تحديد تاريخ البداية والنهاية يدوياً.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }
    }

    fun showDatePicker(initialMillis: Long, onDateSelected: (Long) -> Unit) {
        val cal = Calendar.getInstance()
        if (initialMillis > 0) cal.timeInMillis = initialMillis
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val selected = Calendar.getInstance().apply {
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month)
                    set(Calendar.DAY_OF_MONTH, dayOfMonth)
                    set(Calendar.HOUR_OF_DAY, 12)
                }
                onDateSelected(selected.timeInMillis)
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Notice Banner (Triggered when license is within 30 days of expiry or expired)
        if (isDue) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (vehicle.getDaysUntilExpiry() < 0) StatusExpiredContainer else StatusWarningContainer
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                if (vehicle.getDaysUntilExpiry() < 0) StatusExpired else StatusWarning
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationImportant,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (vehicle.getDaysUntilExpiry() < 0)
                                "تنبيه: رخصة السيارة منتهية! يرجى إتمام إجراءات التجديد"
                            else
                                "تنبيه: متبقي أقل من شهر على انتهاء الرخصة! ابدأ في إجراءات التجديد",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = if (vehicle.getDaysUntilExpiry() < 0) StatusExpired else StatusWarning
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "اتبع الخطوات أدناه وارفع الشهادات المطلوبة خطوة بخطوة للجاهزية الكاملة.",
                            fontSize = 12.sp,
                            color = if (vehicle.getDaysUntilExpiry() < 0) StatusExpired.copy(alpha = 0.9f) else StatusWarning.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }

        // Section Title & Progress Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Assignment,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إجراءات تجديد الرخصة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (completedSteps == totalSteps) StatusValid.copy(alpha = 0.15f)
                                else MaterialTheme.colorScheme.primaryContainer
                            )
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "$completedSteps من $totalSteps خطوات مكتملة",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (completedSteps == totalSteps) StatusValid else MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (completedSteps == totalSteps) StatusValid else MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )

                if (vehicle.isRefrigeratedTruck) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f))
                            .padding(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AcUnit,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "سيارة نقل تبريد / تلاجة: تتطلب فحص وشهادة صلاحية من وزارة الصحة",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }
        }

        // Step 1: شهادة بيانات من المرور للتأمينات والضرائب
        DocumentUploadItem(
            stepNumber = "1",
            title = "شهادة بيانات من المرور للتأمينات والضرائب",
            description = "استخراج شهادة بيانات موجهة للضرائب والتأمينات من وحدة المرور التابع لها.",
            isCompleted = vehicle.trafficDataCertCompleted,
            imagePath = vehicle.trafficDataCertPath,
            onImageSaved = { path ->
                onUpdateVehicle(vehicle.copy(trafficDataCertPath = path, trafficDataCertCompleted = true))
            },
            onImageRemoved = {
                onUpdateVehicle(vehicle.copy(trafficDataCertPath = null, trafficDataCertCompleted = false))
            },
            onToggleCompleted = { isDone ->
                onUpdateVehicle(vehicle.copy(trafficDataCertCompleted = isDone))
            }
        )

        // Step 2: شهادة الضرائب
        DocumentUploadItem(
            stepNumber = "2",
            title = "شهادة الضرائب (سداد / براءة ذمة)",
            description = "التوجه لمأمورية الضرائب المختصة بالشهادة وسداد المستحقات واستلام شهادة براءة الذمة.",
            isCompleted = vehicle.taxCertCompleted,
            imagePath = vehicle.taxCertPath,
            onImageSaved = { path ->
                onUpdateVehicle(vehicle.copy(taxCertPath = path, taxCertCompleted = true))
            },
            onImageRemoved = {
                onUpdateVehicle(vehicle.copy(taxCertPath = null, taxCertCompleted = false))
            },
            onToggleCompleted = { isDone ->
                onUpdateVehicle(vehicle.copy(taxCertCompleted = isDone))
            }
        )

        // Step 3: شهادة التأمينات الاجتماعية (مع ربط السائق والأرقام التأمينية والبطاقة والرخصة)
        Card(
            modifier = Modifier.fillMaxWidth().testTag("doc_step_3"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (vehicle.insuranceCertCompleted) StatusValidContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface
            ),
            border = if (vehicle.insuranceCertCompleted) BorderStroke(1.dp, StatusValid.copy(alpha = 0.5f)) else null
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Step 3 Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(if (vehicle.insuranceCertCompleted) StatusValid else MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "3",
                            color = if (vehicle.insuranceCertCompleted) Color.White else MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "شهادة التأمينات الاجتماعية وسداد التأمين",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (vehicle.insuranceCertCompleted) StatusValid else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "سداد التأمينات واستخراج الشهادة وربط بيانات وتأمينات السيارة والسائق.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(
                        onClick = { onUpdateVehicle(vehicle.copy(insuranceCertCompleted = !vehicle.insuranceCertCompleted)) }
                    ) {
                        Icon(
                            imageVector = if (vehicle.insuranceCertCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = "حالة الإتمام",
                            tint = if (vehicle.insuranceCertCompleted) StatusValid else MaterialTheme.colorScheme.outline
                        )
                    }
                }

                // Insurance Numbers (الرقم التأميني للسيارة ورقم تأمينات السائق)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = vehicle.vehicleInsuranceNumber,
                        onValueChange = { onUpdateVehicle(vehicle.copy(vehicleInsuranceNumber = it)) },
                        label = { Text("الرقم التأميني للسيارة") },
                        placeholder = { Text("مثال: 940218") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = vehicle.driverInsuranceNumber,
                        onValueChange = { onUpdateVehicle(vehicle.copy(driverInsuranceNumber = it)) },
                        label = { Text("الرقم التأميني للسائق") },
                        placeholder = { Text("مثال: 184092") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                // Certificate image upload
                val insuranceCertPicker = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.PickVisualMedia()
                ) { uri ->
                    if (uri != null) {
                        val path = FileStorageUtils.saveImageToInternalStorage(context, uri, prefix = "insurance_cert")
                        if (path != null) onUpdateVehicle(vehicle.copy(insuranceCertPath = path))
                    }
                }

                if (!vehicle.insuranceCertPath.isNullOrEmpty() && File(vehicle.insuranceCertPath).exists()) {
                    UploadedDocPreviewRow(
                        title = "شهادة التأمينات الرسمية",
                        filePath = vehicle.insuranceCertPath,
                        onView = {
                            viewingDocumentPath = vehicle.insuranceCertPath
                            viewingDocumentTitle = "شهادة التأمينات الاجتماعية"
                        },
                        onDelete = {
                            FileStorageUtils.deleteInternalFile(vehicle.insuranceCertPath)
                            onUpdateVehicle(vehicle.copy(insuranceCertPath = null))
                        }
                    )
                } else {
                    OutlinedButton(
                        onClick = {
                            insuranceCertPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تحميل صورة شهادة التأمينات الاجتماعية")
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                // Driver Assignment Section (ربط سائق بسيارة)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("ربط سائق بالسيارة", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                            Text("إرفاق بطاقة الرقم القومي ورخصة قيادة السائق", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Switch(
                        checked = vehicle.hasAssignedDriver,
                        onCheckedChange = { onUpdateVehicle(vehicle.copy(hasAssignedDriver = it)) }
                    )
                }

                AnimatedVisibility(visible = vehicle.hasAssignedDriver) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = vehicle.driverName,
                            onValueChange = { onUpdateVehicle(vehicle.copy(driverName = it)) },
                            label = { Text("اسم السائق الكامل") },
                            placeholder = { Text("محمد حسن إبراهيم") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        // Driver ID card
                        if (!vehicle.driverNationalIdImagePath.isNullOrEmpty() && File(vehicle.driverNationalIdImagePath).exists()) {
                            UploadedDocPreviewRow(
                                title = "بطاقة الرقم القومي للسائق",
                                filePath = vehicle.driverNationalIdImagePath,
                                onView = {
                                    viewingDocumentPath = vehicle.driverNationalIdImagePath
                                    viewingDocumentTitle = "بطاقة الرقم القومي للسائق"
                                },
                                onDelete = {
                                    FileStorageUtils.deleteInternalFile(vehicle.driverNationalIdImagePath)
                                    onUpdateVehicle(vehicle.copy(driverNationalIdImagePath = null))
                                }
                            )
                        } else {
                            OutlinedButton(
                                onClick = {
                                    driverIdPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Badge, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("تحميل صورة البطاقة الشخصية للسائق")
                            }
                        }

                        // Driver License
                        if (!vehicle.driverLicenseImagePath.isNullOrEmpty() && File(vehicle.driverLicenseImagePath).exists()) {
                            UploadedDocPreviewRow(
                                title = "رخصة قيادة السائق",
                                filePath = vehicle.driverLicenseImagePath,
                                onView = {
                                    viewingDocumentPath = vehicle.driverLicenseImagePath
                                    viewingDocumentTitle = "رخصة قيادة السائق"
                                },
                                onDelete = {
                                    FileStorageUtils.deleteInternalFile(vehicle.driverLicenseImagePath)
                                    onUpdateVehicle(vehicle.copy(driverLicenseImagePath = null))
                                }
                            )
                        } else {
                            OutlinedButton(
                                onClick = {
                                    driverLicensePickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.DriveEta, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("تحميل صورة رخصة قيادة السائق")
                            }
                        }
                    }
                }

                if (!vehicle.insuranceCertCompleted) {
                    FilledTonalButton(
                        onClick = { onUpdateVehicle(vehicle.copy(insuranceCertCompleted = true)) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تأكيد إتمام خطوة التأمينات", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Step 4 (Conditional): فحص وزارة الصحة وشهادة صلاحية التلاجة
        if (vehicle.isRefrigeratedTruck) {
            DocumentUploadItem(
                stepNumber = "4",
                title = "فحص وزارة الصحة وشهادة صلاحية التلاجة",
                description = "إلزامية لسيارات التبريد والتلاجة: فحص وحدة التبريد ودرجات الحرارة واستخراج شهادة الصلاحية الصحية لنقل المواد الغذائية.",
                isCompleted = vehicle.healthCertCompleted,
                imagePath = vehicle.healthCertPath,
                onImageSaved = { path ->
                    onUpdateVehicle(vehicle.copy(healthCertPath = path, healthCertCompleted = true))
                },
                onImageRemoved = {
                    onUpdateVehicle(vehicle.copy(healthCertPath = null, healthCertCompleted = false))
                },
                onToggleCompleted = { isDone ->
                    onUpdateVehicle(vehicle.copy(healthCertCompleted = isDone))
                }
            )
        }

        // Step 5: الفحص الفني النهائي للمرور وإصدار الرخصة
        val finalStepNumber = if (vehicle.isRefrigeratedTruck) "5" else "4"
        Card(
            modifier = Modifier.fillMaxWidth().testTag("final_inspection_step_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (vehicle.finalInspectionCompleted) StatusValidContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface
            ),
            border = BorderStroke(1.5.dp, if (vehicle.finalInspectionCompleted) StatusValid else MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(if (vehicle.finalInspectionCompleted) StatusValid else MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = finalStepNumber,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "الفحص الفني النهائي للمرور وإصدار الرخصة الجديدة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (vehicle.finalInspectionCompleted) StatusValid else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "ارفع صورة الرخصة الجديدة وسيقوم التطبيق بقراءة تواريخ البداية والنهاية واعتمادها فوراً!",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (vehicle.finalInspectionCompleted) {
                        Icon(Icons.Default.CheckCircle, contentDescription = "مكتملة", tint = StatusValid)
                    }
                }

                // If loading OCR dates
                if (isReadingFinalLicenseDates) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 3.dp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "جاري قراءة تاريخ بداية وانتهاء الرخصة الجديدة بالذكاء الاصطناعي...",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // Final license image preview or upload button
                if (!vehicle.finalInspectionCertPath.isNullOrEmpty() && File(vehicle.finalInspectionCertPath).exists()) {
                    UploadedDocPreviewRow(
                        title = "صورة رخصة التسيير الجديدة",
                        filePath = vehicle.finalInspectionCertPath,
                        onView = {
                            viewingDocumentPath = vehicle.finalInspectionCertPath
                            viewingDocumentTitle = "صورة الرخصة الجديدة"
                        },
                        onDelete = {
                            FileStorageUtils.deleteInternalFile(vehicle.finalInspectionCertPath)
                            onUpdateVehicle(vehicle.copy(finalInspectionCertPath = null, finalInspectionCompleted = false))
                        }
                    )

                    // Display detected dates and confirm button
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "📅 تواريخ سريان الرخصة الجديدة المستخرجة:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.primary
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("تاريخ بداية الرخصة (الإصدار):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        text = formatArabicDate(detectedNewIssueDate),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                                IconButton(onClick = { showDatePicker(detectedNewIssueDate) { detectedNewIssueDate = it } }) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("تاريخ انتهاء الرخصة الجديد:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        text = formatArabicDate(detectedNewExpiryDate),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = StatusValid
                                    )
                                }
                                IconButton(onClick = { showDatePicker(detectedNewExpiryDate) { detectedNewExpiryDate = it } }) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Button(
                                onClick = {
                                    // Officially adopt the new dates and reset renewal flags for future
                                    val updated = vehicle.copy(
                                        licenseIssueDateMillis = detectedNewIssueDate,
                                        licenseExpiryDateMillis = detectedNewExpiryDate,
                                        licenseImagePath = vehicle.finalInspectionCertPath,
                                        finalInspectionCompleted = true,
                                        trafficDataCertCompleted = false,
                                        taxCertCompleted = false,
                                        insuranceCertCompleted = false,
                                        healthCertCompleted = false
                                    )
                                    onUpdateVehicle(updated)
                                    Toast.makeText(
                                        context,
                                        "تم اعتماد وتحديث رخصة السيارة رسمياً بالتاريخ الجديد!",
                                        Toast.LENGTH_LONG
                                    ).show()
                                },
                                modifier = Modifier.fillMaxWidth().testTag("confirm_new_license_dates_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = StatusValid),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "اعتماد تواريخ الرخصة وتحديث السيارة رسمياً",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp
                                )
                            }
                        }
                    }
                } else {
                    Button(
                        onClick = {
                            finalLicensePickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تحميل صورة الرخصة النهائية الجديدة واستخراج التواريخ",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }

    if (!viewingDocumentPath.isNullOrEmpty()) {
        FullScreenImageViewer(
            imagePath = viewingDocumentPath!!,
            title = viewingDocumentTitle,
            onDismiss = { viewingDocumentPath = null }
        )
    }
}

@Composable
fun UploadedDocPreviewRow(
    title: String,
    filePath: String,
    onView: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f).clickable(onClick = onView)
        ) {
            AsyncImage(
                model = File(filePath),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                Text(text = "محفوظة في الهاتف • اضغط للمعاينة", fontSize = 10.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Row {
            IconButton(onClick = onView) {
                Icon(Icons.Default.Visibility, contentDescription = "معاينة", tint = MaterialTheme.colorScheme.primary)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}
