package com.example.ui.screens

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.DriveEta
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import com.example.ui.components.FullScreenImageViewer
import java.io.File
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ai.LicenseOcrService
import com.example.data.model.VehicleLicense
import com.example.ui.components.LicensePhotoCard
import com.example.ui.components.formatArabicDate
import com.example.ui.viewmodel.VehicleViewModel
import com.example.utils.FileStorageUtils
import kotlinx.coroutines.launch
import java.util.Calendar

val PredefinedColors = listOf(
    Pair("أبيض", 0xFFE2E8F0),
    Pair("أسود", 0xFF0F172A),
    Pair("فضي", 0xFF94A3B8),
    Pair("رمادي", 0xFF64748B),
    Pair("كحلي", 0xFF1E3A8A),
    Pair("أزرق", 0xFF2563EB),
    Pair("أحمر", 0xFFDC2626),
    Pair("ذهبي", 0xFFD97706),
    Pair("بني", 0xFF78350F)
)

val VehicleTypes = listOf("ملاكي", "أجرة", "نقل", "دراجة نارية", "أخرى")

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddEditVehicleScreen(
    vehicleId: Long?,
    viewModel: VehicleViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val vehicles by viewModel.allVehicles.collectAsStateWithLifecycle()
    val existing = vehicleId?.let { id -> vehicles.find { it.id == id } }

    val isEditing = existing != null

    // Form fields state
    var vehicleCode by remember(existing) { mutableStateOf(existing?.vehicleCode ?: "") }
    var makeAndModel by remember(existing) { mutableStateOf(existing?.makeAndModel ?: "") }
    var manufactureYear by remember(existing) {
        mutableStateOf(existing?.manufactureYear?.toString() ?: Calendar.getInstance().get(Calendar.YEAR).toString())
    }
    var plateNumber by remember(existing) { mutableStateOf(existing?.plateNumber ?: "") }
    var vehicleType by remember(existing) { mutableStateOf(existing?.vehicleType ?: "ملاكي") }
    var isRefrigeratedTruck by remember(existing) { mutableStateOf(existing?.isRefrigeratedTruck ?: false) }
    var colorName by remember(existing) { mutableStateOf(existing?.colorName ?: "أبيض") }
    var colorHex by remember(existing) { mutableLongStateOf(existing?.colorHex ?: 0xFFE2E8F0) }

    // Insurance & Driver fields
    var vehicleInsuranceNumber by remember(existing) { mutableStateOf(existing?.vehicleInsuranceNumber ?: "") }
    var driverInsuranceNumber by remember(existing) { mutableStateOf(existing?.driverInsuranceNumber ?: "") }
    var hasAssignedDriver by remember(existing) { mutableStateOf(existing?.hasAssignedDriver ?: false) }
    var driverName by remember(existing) { mutableStateOf(existing?.driverName ?: "") }
    var driverNationalIdImagePath by remember(existing) { mutableStateOf(existing?.driverNationalIdImagePath) }
    var driverLicenseImagePath by remember(existing) { mutableStateOf(existing?.driverLicenseImagePath) }

    // Fullscreen viewing
    var viewingDocumentPath by remember { mutableStateOf<String?>(null) }
    var viewingDocumentTitle by remember { mutableStateOf("") }

    // Image path
    var licenseImagePath by remember(existing) { mutableStateOf(existing?.licenseImagePath) }

    // Dates
    val oneYearFromNow = Calendar.getInstance().apply { add(Calendar.YEAR, 1) }.timeInMillis
    var expiryDateMillis by remember(existing) {
        mutableLongStateOf(existing?.licenseExpiryDateMillis ?: oneYearFromNow)
    }
    var issueDateMillis by remember(existing) {
        mutableLongStateOf(existing?.licenseIssueDateMillis ?: System.currentTimeMillis())
    }
    var inspectionDateMillis by remember(existing) {
        mutableLongStateOf(existing?.inspectionExpiryMillis ?: 0L)
    }
    var insuranceDateMillis by remember(existing) {
        mutableLongStateOf(existing?.insuranceExpiryMillis ?: 0L)
    }

    // Traffic & Specs
    var trafficDepartment by remember(existing) { mutableStateOf(existing?.trafficDepartment ?: "") }
    var governorate by remember(existing) { mutableStateOf(existing?.governorate ?: "القاهرة") }
    var chassisNumber by remember(existing) { mutableStateOf(existing?.chassisNumber ?: "") }
    var motorNumber by remember(existing) { mutableStateOf(existing?.motorNumber ?: "") }
    var renewalCost by remember(existing) {
        mutableStateOf(if (existing != null && existing.estimatedRenewalCost > 0) existing.estimatedRenewalCost.toInt().toString() else "")
    }
    var ownerName by remember(existing) { mutableStateOf(existing?.ownerName ?: "") }
    var ownerNationalId by remember(existing) { mutableStateOf(existing?.ownerNationalId ?: "") }
    var notes by remember(existing) { mutableStateOf(existing?.notes ?: "") }

    var typeDropdownExpanded by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }

    // AI Smart Scan states
    var isScanningWithAi by remember { mutableStateOf(false) }
    var aiScanError by remember { mutableStateOf<String?>(null) }

    // AI Photo Picker launcher
    val aiOcrPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val savedPath = FileStorageUtils.saveImageToInternalStorage(
                context = context,
                sourceUri = uri,
                prefix = "license_ai_scan"
            )
            if (savedPath != null) {
                licenseImagePath = savedPath
                isScanningWithAi = true
                aiScanError = null

                coroutineScope.launch {
                    val result = LicenseOcrService.extractDataFromLicenseImage(context, File(savedPath))
                    isScanningWithAi = false

                    result.onSuccess { data ->
                        data.vehicleCode?.let { vehicleCode = it }
                        data.makeAndModel?.let { makeAndModel = it }
                        data.manufactureYear?.let { manufactureYear = it.toString() }
                        data.plateNumber?.let { plateNumber = it }
                        data.vehicleType?.let { vehicleType = it }
                        if (data.isRefrigeratedTruck) isRefrigeratedTruck = true
                        data.colorName?.let { cName ->
                            colorName = cName
                            PredefinedColors.find { pair -> pair.first in cName || cName in pair.first }?.let { pair ->
                                colorHex = pair.second
                            }
                        }
                        data.licenseExpiryDateMillis?.let { expiryDateMillis = it }
                        data.licenseIssueDateMillis?.let { issueDateMillis = it }
                        data.trafficDepartment?.let { trafficDepartment = it }
                        data.governorate?.let { governorate = it }
                        data.chassisNumber?.let { chassisNumber = it }
                        data.motorNumber?.let { motorNumber = it }
                        data.ownerName?.let { ownerName = it }
                        data.ownerNationalId?.let { ownerNationalId = it }
                        data.notes?.let { notes = it }

                        Toast.makeText(
                            context,
                            "تمت قراءة بيانات الرخصة بنجاح! راجع البيانات وأكمل ما يلزم ثم اضغط حفظ.",
                            Toast.LENGTH_LONG
                        ).show()
                    }.onFailure { error ->
                        aiScanError = error.message ?: "تعذر قراءة بيانات الرخصة تلقائياً. يمكنك إدخال البيانات يدوياً."
                    }
                }
            }
        }
    }

    val driverIdPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val localPath = FileStorageUtils.saveImageToInternalStorage(context, uri, prefix = "driver_id")
            if (localPath != null) {
                driverNationalIdImagePath = localPath
                Toast.makeText(context, "تم حفظ صورة بطاقة السائق في الهاتف", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val driverLicensePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val localPath = FileStorageUtils.saveImageToInternalStorage(context, uri, prefix = "driver_license")
            if (localPath != null) {
                driverLicenseImagePath = localPath
                Toast.makeText(context, "تم حفظ صورة رخصة السائق في الهاتف", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun showDatePicker(initialMillis: Long, onDateSelected: (Long) -> Unit) {
        val cal = Calendar.getInstance()
        if (initialMillis > 0) cal.timeInMillis = initialMillis
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val selected = Calendar.getInstance().apply {
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month)
                    set(Calendar.DAY_OF_MONTH, dayOfMonth)
                    set(Calendar.HOUR_OF_DAY, 12)
                    set(Calendar.MINUTE, 0)
                }
                onDateSelected(selected.timeInMillis)
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    // Main Save Action
    val performSave: () -> Unit = {
        if (makeAndModel.trim().isEmpty()) {
            validationError = "يرجى إدخال ماركة وموديل السيارة"
        } else if (plateNumber.trim().isEmpty()) {
            validationError = "يرجى إدخال رقم اللوحة المعدنية"
        } else {
            val yearInt = manufactureYear.toIntOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)
            val costDouble = renewalCost.toDoubleOrNull() ?: 0.0

            val updatedVehicle = VehicleLicense(
                id = existing?.id ?: 0L,
                vehicleCode = vehicleCode.trim(),
                makeAndModel = makeAndModel.trim(),
                manufactureYear = yearInt,
                plateNumber = plateNumber.trim(),
                vehicleType = vehicleType,
                isRefrigeratedTruck = isRefrigeratedTruck,
                colorName = colorName,
                colorHex = colorHex,
                licenseExpiryDateMillis = expiryDateMillis,
                licenseIssueDateMillis = issueDateMillis,
                trafficDepartment = trafficDepartment.trim(),
                governorate = governorate.trim(),
                chassisNumber = chassisNumber.trim(),
                motorNumber = motorNumber.trim(),
                inspectionExpiryMillis = inspectionDateMillis,
                insuranceExpiryMillis = insuranceDateMillis,
                estimatedRenewalCost = costDouble,
                ownerName = ownerName.trim(),
                ownerNationalId = ownerNationalId.trim(),
                notes = notes.trim(),
                licenseImagePath = licenseImagePath,
                // Insurance and Driver info
                vehicleInsuranceNumber = vehicleInsuranceNumber.trim(),
                driverInsuranceNumber = driverInsuranceNumber.trim(),
                hasAssignedDriver = hasAssignedDriver,
                driverName = driverName.trim(),
                driverNationalIdImagePath = driverNationalIdImagePath,
                driverLicenseImagePath = driverLicenseImagePath,
                // Preserve existing renewal procedure state if editing
                trafficDataCertPath = existing?.trafficDataCertPath,
                trafficDataCertCompleted = existing?.trafficDataCertCompleted ?: false,
                taxCertPath = existing?.taxCertPath,
                taxCertCompleted = existing?.taxCertCompleted ?: false,
                insuranceCertPath = existing?.insuranceCertPath,
                insuranceCertCompleted = existing?.insuranceCertCompleted ?: false,
                healthCertPath = existing?.healthCertPath,
                healthCertCompleted = existing?.healthCertCompleted ?: false,
                finalInspectionCertPath = existing?.finalInspectionCertPath,
                finalInspectionCompleted = existing?.finalInspectionCompleted ?: false
            )

            viewModel.saveVehicle(updatedVehicle) {
                Toast.makeText(
                    context,
                    if (isEditing) "تم تعديل بيانات السيارة بنجاح" else "تم حفظ بيانات السيارة بنجاح",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isEditing) "تعديل بيانات المركبة" else "إضافة سيارة جديدة",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier.testTag("add_edit_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "الرجوع")
                    }
                },
                actions = {
                    Button(
                        onClick = performSave,
                        modifier = Modifier.testTag("save_vehicle_top_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("حفظ", fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Button(
                        onClick = performSave,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("save_vehicle_bottom_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isEditing) "حفظ التعديلات" else "حفظ بيانات السيارة",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Validation or AI scan error card
            validationError?.let { error ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = error,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(12.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            aiScanError?.let { error ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.8f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "ملاحظة في القراءة التلقائية:",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Text(
                                text = error,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        TextButton(onClick = { aiScanError = null }) {
                            Text("إغلاق", color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }
            }

            // AI Smart Scan Card (القارئ الذكي لرخص السيارات بالذكاء الاصطناعي)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ai_ocr_scan_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                ),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "القراءة التلقائية الذكية للرخصة (AI OCR)",
                                fontWeight = FontWeight.Black,
                                fontSize = 14.5.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "ارفع صورة الرخصة وسيقرأ التطبيق الموديل، اللوحة، وتاريخ الانتهاء ويعبئ كافة البيانات تلقائياً!",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            aiOcrPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("ai_scan_license_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DocumentScanner,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "رفع صورة الرخصة وقراءة البيانات تلقائياً",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp
                        )
                    }
                }
            }

            // Photo Card: License Photo saved locally in phone
            LicensePhotoCard(
                imagePath = licenseImagePath,
                onImageSelected = { licenseImagePath = it },
                onImageDeleted = { licenseImagePath = null }
            )

            // Section 1: Basic Vehicle Info
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "البيانات الأساسية للمركبة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    OutlinedTextField(
                        value = vehicleCode,
                        onValueChange = { vehicleCode = it },
                        label = { Text("كود السيارة") },
                        placeholder = { Text("مثال: CAR-101 أو 502") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_vehicle_code"),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = makeAndModel,
                        onValueChange = {
                            makeAndModel = it
                            validationError = null
                        },
                        label = { Text("الماركة والموديل *") },
                        placeholder = { Text("مثال: تويوتا كورولا، إيسوزو نقل") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_make_model"),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = plateNumber,
                            onValueChange = {
                                plateNumber = it
                                validationError = null
                            },
                            label = { Text("رقم اللوحة المعدنية *") },
                            placeholder = { Text("مثال: س ر ج ٤٨١٩") },
                            modifier = Modifier
                                .weight(1.3f)
                                .testTag("input_plate_number"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = manufactureYear,
                            onValueChange = { manufactureYear = it },
                            label = { Text("سنة الصنع") },
                            modifier = Modifier
                                .weight(0.9f)
                                .testTag("input_year"),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true
                        )
                    }

                    // Vehicle Type Dropdown
                    ExposedDropdownMenuBox(
                        expanded = typeDropdownExpanded,
                        onExpandedChange = { typeDropdownExpanded = !typeDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = vehicleType,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("نوع الترخيص") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeDropdownExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = typeDropdownExpanded,
                            onDismissRequest = { typeDropdownExpanded = false }
                        ) {
                            VehicleTypes.forEach { type ->
                                DropdownMenuItem(
                                    text = { Text(type) },
                                    onClick = {
                                        vehicleType = type
                                        typeDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Refrigerated Truck Switch
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isRefrigeratedTruck) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            )
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AcUnit,
                                contentDescription = null,
                                tint = if (isRefrigeratedTruck) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "سيارة نقل تبريد / تلاجة؟",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp
                                )
                                Text(
                                    text = "يتطلب تجديدها فحص وزارة الصحة وشهادة صلاحية التلاجة",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = isRefrigeratedTruck,
                            onCheckedChange = { isRefrigeratedTruck = it }
                        )
                    }

                    // Color Selector
                    Text(
                        text = "لون السيارة: $colorName",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PredefinedColors.forEach { (name, hex) ->
                            val isSelected = colorName == name
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(hex))
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else Color(0xFFCBD5E1),
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        colorName = name
                                        colorHex = hex
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = if (hex == 0xFFE2E8F0 || hex == 0xFF94A3B8) Color.Black else Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Section 2: License Dates & Traffic
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "بيانات رخصة التسيير والانتهاء",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // License Expiration Date (Most important!)
                    OutlinedTextField(
                        value = formatArabicDate(expiryDateMillis),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("تاريخ انتهاء الرخصة * (انقر للتعديل)") },
                        trailingIcon = {
                            IconButton(onClick = {
                                showDatePicker(expiryDateMillis) { expiryDateMillis = it }
                            }) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = "اختيار التاريخ")
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showDatePicker(expiryDateMillis) { expiryDateMillis = it }
                            }
                    )

                    // Quick duration presets for expiry date
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "تمديد سريع:",
                            fontSize = 11.sp,
                            modifier = Modifier.align(Alignment.CenterVertically),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        FilterChip(
                            selected = false,
                            onClick = {
                                val cal = Calendar.getInstance().apply { add(Calendar.YEAR, 1) }
                                expiryDateMillis = cal.timeInMillis
                            },
                            label = { Text("+ سنة", fontSize = 11.sp) }
                        )
                        FilterChip(
                            selected = false,
                            onClick = {
                                val cal = Calendar.getInstance().apply { add(Calendar.YEAR, 2) }
                                expiryDateMillis = cal.timeInMillis
                            },
                            label = { Text("+ سنتين", fontSize = 11.sp) }
                        )
                        FilterChip(
                            selected = false,
                            onClick = {
                                val cal = Calendar.getInstance().apply { add(Calendar.YEAR, 3) }
                                expiryDateMillis = cal.timeInMillis
                            },
                            label = { Text("+ 3 سنوات", fontSize = 11.sp) }
                        )
                    }

                    // License Issue Date
                    OutlinedTextField(
                        value = formatArabicDate(issueDateMillis),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("تاريخ إصدار الرخصة") },
                        trailingIcon = {
                            IconButton(onClick = {
                                showDatePicker(issueDateMillis) { issueDateMillis = it }
                            }) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = "اختيار تاريخ الإصدار")
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showDatePicker(issueDateMillis) { issueDateMillis = it }
                            }
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = trafficDepartment,
                            onValueChange = { trafficDepartment = it },
                            label = { Text("وحدة المرور") },
                            placeholder = { Text("مرور مدينة نصر") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = governorate,
                            onValueChange = { governorate = it },
                            label = { Text("المحافظة") },
                            placeholder = { Text("القاهرة") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
            }

            // Section 3: Technical & Inspection Info
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "البيانات الفنية والفحص الدوري",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    OutlinedTextField(
                        value = chassisNumber,
                        onValueChange = { chassisNumber = it },
                        label = { Text("رقم الشاسيه (VIN)") },
                        placeholder = { Text("JTDBR32E602981440") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = motorNumber,
                        onValueChange = { motorNumber = it },
                        label = { Text("رقم المحرك (الماتور)") },
                        placeholder = { Text("1ZR-7489211") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // Technical Inspection Date
                    OutlinedTextField(
                        value = if (inspectionDateMillis > 0) formatArabicDate(inspectionDateMillis) else "غير محدد",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("تاريخ الفحص الفني الدوري القادم") },
                        trailingIcon = {
                            Row {
                                if (inspectionDateMillis > 0) {
                                    TextButton(onClick = { inspectionDateMillis = 0L }) {
                                        Text("مسح", fontSize = 11.sp)
                                    }
                                }
                                IconButton(onClick = {
                                    showDatePicker(inspectionDateMillis) { inspectionDateMillis = it }
                                }) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = "اختيار التاريخ")
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showDatePicker(inspectionDateMillis) { inspectionDateMillis = it }
                            }
                    )

                    // Insurance Expiry Date
                    OutlinedTextField(
                        value = if (insuranceDateMillis > 0) formatArabicDate(insuranceDateMillis) else "غير محدد",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("تاريخ انتهاء التأمين الإجباري") },
                        trailingIcon = {
                            Row {
                                if (insuranceDateMillis > 0) {
                                    TextButton(onClick = { insuranceDateMillis = 0L }) {
                                        Text("مسح", fontSize = 11.sp)
                                    }
                                }
                                IconButton(onClick = {
                                    showDatePicker(insuranceDateMillis) { insuranceDateMillis = it }
                                }) {
                                    Icon(Icons.Default.CalendarMonth, contentDescription = "اختيار التاريخ")
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showDatePicker(insuranceDateMillis) { insuranceDateMillis = it }
                            }
                    )
                }
            }

            // Section: Insurance Numbers & Driver Linking (الرقم التأميني للسيارة والسائق وربط السائق)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "التأمينات وربط السائق بالسيارة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = vehicleInsuranceNumber,
                            onValueChange = { vehicleInsuranceNumber = it },
                            label = { Text("الرقم التأميني للسيارة") },
                            placeholder = { Text("مثال: 940218") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = driverInsuranceNumber,
                            onValueChange = { driverInsuranceNumber = it },
                            label = { Text("الرقم التأميني للسائق") },
                            placeholder = { Text("مثال: 184092") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    // Driver Linking Switch
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("ربط سائق بالسيارة", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                                Text("إرفاق بطاقة الرقم القومي ورخصة القيادة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        Switch(
                            checked = hasAssignedDriver,
                            onCheckedChange = { hasAssignedDriver = it }
                        )
                    }

                    if (hasAssignedDriver) {
                        OutlinedTextField(
                            value = driverName,
                            onValueChange = { driverName = it },
                            label = { Text("اسم السائق الكامل") },
                            placeholder = { Text("محمد حسن إبراهيم") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        // Driver ID Button / Preview
                        if (!driverNationalIdImagePath.isNullOrEmpty() && File(driverNationalIdImagePath!!).exists()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Badge, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("بطاقة السائق محفوظة", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                                }
                                Row {
                                    IconButton(onClick = {
                                        viewingDocumentPath = driverNationalIdImagePath
                                        viewingDocumentTitle = "بطاقة الرقم القومي للسائق"
                                    }) {
                                        Icon(Icons.Default.Visibility, contentDescription = "معاينة", tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(onClick = { driverNationalIdImagePath = null }) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    driverIdPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Badge, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("تحميل صورة البطاقة الشخصية للسائق")
                            }
                        }

                        // Driver License Button / Preview
                        if (!driverLicenseImagePath.isNullOrEmpty() && File(driverLicenseImagePath!!).exists()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.DriveEta, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("رخصة قيادة السائق محفوظة", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                                }
                                Row {
                                    IconButton(onClick = {
                                        viewingDocumentPath = driverLicenseImagePath
                                        viewingDocumentTitle = "رخصة قيادة السائق"
                                    }) {
                                        Icon(Icons.Default.Visibility, contentDescription = "معاينة", tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(onClick = { driverLicenseImagePath = null }) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    driverLicensePickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.DriveEta, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("تحميل صورة رخصة قيادة السائق")
                            }
                        }
                    }
                }
            }

            // Section 4: Owner & Costs
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "بيانات المالك والرسوم التقديرية",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    OutlinedTextField(
                        value = ownerName,
                        onValueChange = { ownerName = it },
                        label = { Text("اسم المالك") },
                        placeholder = { Text("أحمد محمد محمود") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = ownerNationalId,
                        onValueChange = { ownerNationalId = it },
                        label = { Text("الرقم القومي / الهوية") },
                        placeholder = { Text("29410150102345") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = renewalCost,
                        onValueChange = { renewalCost = it },
                        label = { Text("تقدير رسوم التجديد والضريبة (ج.م)") },
                        placeholder = { Text("2500") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات وشروط خاصة") },
                        placeholder = { Text("مطلوب استخراج براءة ذمة، فحص دوري في مرور الشروق...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Scanning Loading Dialog
    if (isScanningWithAi) {
        Dialog(
            onDismissRequest = {},
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(54.dp),
                        color = MaterialTheme.colorScheme.primary,
                        strokeWidth = 4.dp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "جاري قراءة صورة الرخصة الذكية...",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "يقوم الذكاء الاصطناعي باستخراج الموديل، رقم اللوحة، تاريخ الانتهاء، الشاسيه، وبيانات المرور بدقة.",
                        fontSize = 12.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }

    if (!viewingDocumentPath.isNullOrEmpty()) {
        FullScreenImageViewer(
            imagePath = viewingDocumentPath!!,
            title = viewingDocumentTitle,
            onDismiss = { viewingDocumentPath = null }
        )
    }
}
