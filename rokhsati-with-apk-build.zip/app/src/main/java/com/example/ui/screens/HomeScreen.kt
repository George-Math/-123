package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import com.example.data.model.UserRole
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.VehicleLicense
import com.example.ui.components.VehicleLicenseCard
import com.example.ui.components.formatArabicDate
import com.example.ui.theme.StatusExpired
import com.example.ui.theme.StatusExpiredContainer
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningContainer
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.VehicleFilter
import com.example.ui.viewmodel.VehicleSort
import com.example.ui.viewmodel.VehicleViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: VehicleViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val vehicles by viewModel.filteredVehicles.collectAsStateWithLifecycle()
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val currentFilter by viewModel.filter.collectAsStateWithLifecycle()
    val currentSort by viewModel.sortOrder.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

    var showSortMenu by remember { mutableStateOf(false) }
    var vehicleToDelete by remember { mutableStateOf<VehicleLicense?>(null) }
    var showLogoutConfirm by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.DirectionsCar,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "شركة إكس كار",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (currentUser?.role == UserRole.ADMIN) MaterialTheme.colorScheme.secondaryContainer
                                    else MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Text(
                                        text = if (currentUser?.role == UserRole.ADMIN) "المسئول (1507)" else "مستخدم (${currentUser?.username ?: "1"})",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (currentUser?.role == UserRole.ADMIN) MaterialTheme.colorScheme.onSecondaryContainer
                                        else MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "متابعة رخص وتجديد المركبات",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    if (currentUser?.role == UserRole.ADMIN) {
                        IconButton(
                            onClick = { viewModel.navigateTo(Screen.AdminUsers) },
                            modifier = Modifier.testTag("admin_users_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = "إدارة المستخدمين",
                                tint = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.Analytics) },
                        modifier = Modifier.testTag("analytics_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Insights,
                            contentDescription = "الإحصائيات والرسوم",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = { showLogoutConfirm = true },
                        modifier = Modifier.testTag("logout_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "تسجيل الخروج",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { viewModel.navigateTo(Screen.AddEdit()) },
                modifier = Modifier.testTag("add_vehicle_fab"),
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("إضافة سيارة", fontWeight = FontWeight.Bold) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Urgent Alert Banner (if any car is expired or expiring soon)
            AnimatedVisibility(
                visible = stats.expiredCount > 0 || stats.expiringSoonCount > 0,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                if (stats.expiredCount > 0) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = StatusExpiredContainer),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Error,
                                contentDescription = null,
                                tint = StatusExpired,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "تنبيه: توجد ${stats.expiredCount} سيارة رخصتها منتهية!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp,
                                    color = StatusExpired
                                )
                                Text(
                                    text = "يجب تجديد الرخصة فوراً لتفادي غرامات التأخير وسحب اللوحات.",
                                    fontSize = 11.5.sp,
                                    color = StatusExpired.copy(alpha = 0.85f)
                                )
                            }
                            TextButton(onClick = { viewModel.setFilter(VehicleFilter.EXPIRED) }) {
                                Text("عرض", color = StatusExpired, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else if (stats.expiringSoonCount > 0) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = StatusWarningContainer),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = StatusWarning,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "تنبيه: اقترب موعد التجديد (أقل من شهر) لـ ${stats.expiringSoonCount} سيارة!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp,
                                    color = StatusWarning
                                )
                                Text(
                                    text = "ابدأ إجراءات التجديد: شهادة بيانات المرور، الضرائب، التأمينات، فحص التلاجة (إن وُجدت)، والفحص النهائي.",
                                    fontSize = 11.5.sp,
                                    color = StatusWarning.copy(alpha = 0.85f)
                                )
                            }
                            TextButton(onClick = { viewModel.setFilter(VehicleFilter.EXPIRING_SOON) }) {
                                Text("بدء الإجراءات", color = StatusWarning, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Search Bar & Sort Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("search_field"),
                    placeholder = { Text("بحث بالموديل، اللوحة، المالك...", fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "مسح", modifier = Modifier.size(18.dp))
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )

                Spacer(modifier = Modifier.width(8.dp))

                Box {
                    IconButton(
                        onClick = { showSortMenu = true },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.FilterList,
                            contentDescription = "ترتيب",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    DropdownMenu(
                        expanded = showSortMenu,
                        onDismissRequest = { showSortMenu = false }
                    ) {
                        VehicleSort.values().forEach { sort ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = sort.label,
                                        fontWeight = if (sort == currentSort) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    viewModel.setSort(sort)
                                    showSortMenu = false
                                }
                            )
                        }
                    }
                }
            }

            // Status Filter Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = currentFilter == VehicleFilter.ALL,
                        onClick = { viewModel.setFilter(VehicleFilter.ALL) },
                        label = { Text("الكل (${stats.totalCount})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = currentFilter == VehicleFilter.VALID,
                        onClick = { viewModel.setFilter(VehicleFilter.VALID) },
                        label = { Text("سارية (${stats.validCount})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = currentFilter == VehicleFilter.EXPIRING_SOON,
                        onClick = { viewModel.setFilter(VehicleFilter.EXPIRING_SOON) },
                        label = { Text("تنتهي قريباً (${stats.expiringSoonCount})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StatusWarningContainer,
                            selectedLabelColor = StatusWarning
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = currentFilter == VehicleFilter.EXPIRED,
                        onClick = { viewModel.setFilter(VehicleFilter.EXPIRED) },
                        label = { Text("منتهية (${stats.expiredCount})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = StatusExpiredContainer,
                            selectedLabelColor = StatusExpired
                        )
                    )
                }
            }

            // Vehicles List or Empty State
            if (vehicles.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.DirectionsCar,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = if (searchQuery.isNotEmpty()) "لا توجد نتائج بحث مطابقة" else "لا توجد مركبات مسجلة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (searchQuery.isNotEmpty())
                                "جرب البحث برقم لوحة مختلف أو اسم السيارة"
                            else
                                "أضف سيارتك الآن لمتابعة رخصة التسيير وتاريخ الانتهاء والفحص الدوري",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { viewModel.navigateTo(Screen.AddEdit()) },
                                modifier = Modifier.testTag("empty_add_vehicle_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إضافة سيارة جديدة", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(vehicles, key = { it.id }) { vehicle ->
                        VehicleLicenseCard(
                            vehicle = vehicle,
                            onClick = { viewModel.navigateTo(Screen.Detail(vehicle.id)) },
                            onEdit = { viewModel.navigateTo(Screen.AddEdit(vehicle.id)) },
                            onDelete = { vehicleToDelete = vehicle },
                            onShare = { shareVehicleSummary(context, vehicle) }
                        )
                    }
                }
            }
        }
    }

    // Delete Confirmation Dialog
    vehicleToDelete?.let { vehicle ->
        AlertDialog(
            onDismissRequest = { vehicleToDelete = null },
            title = { Text("حذف السيارة", fontWeight = FontWeight.Bold) },
            text = {
                Text("هل أنت متأكد من حذف ${vehicle.makeAndModel} (لوحة: ${vehicle.plateNumber})؟ سيتم مسح كافة بيانات رخصة السيارة نهائياً.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteVehicle(vehicle.id)
                        vehicleToDelete = null
                        scope.launch {
                            snackbarHostState.showSnackbar("تم حذف المركبة")
                        }
                    }
                ) {
                    Text("نعم، حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { vehicleToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Logout Confirmation Dialog
    if (showLogoutConfirm) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm = false },
            title = { Text("تسجيل الخروج", fontWeight = FontWeight.Bold) },
            text = { Text("هل تريد بالتأكيد تسجيل الخروج والعودة لشاشة الدخول؟") },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirm = false
                        viewModel.logout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("تسجيل الخروج")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirm = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

fun shareVehicleSummary(context: Context, vehicle: VehicleLicense) {
    val text = buildString {
        appendLine("🚗 بيانات رخصة المركبة:")
        appendLine("الماركة والموديل: ${vehicle.makeAndModel} (${vehicle.manufactureYear})")
        appendLine("رقم اللوحة: ${vehicle.plateNumber}")
        appendLine("نوع الترخيص: ${vehicle.vehicleType}")
        appendLine("اللون: ${vehicle.colorName}")
        appendLine("📅 تاريخ انتهاء الرخصة: ${formatArabicDate(vehicle.licenseExpiryDateMillis)}")
        if (vehicle.trafficDepartment.isNotEmpty()) appendLine("وحدة المرور: ${vehicle.trafficDepartment}")
        if (vehicle.governorate.isNotEmpty()) appendLine("المحافظة: ${vehicle.governorate}")
        if (vehicle.chassisNumber.isNotEmpty()) appendLine("رقم الشاسيه: ${vehicle.chassisNumber}")
        if (vehicle.motorNumber.isNotEmpty()) appendLine("رقم المحرك: ${vehicle.motorNumber}")
        if (vehicle.ownerName.isNotEmpty()) appendLine("اسم المالك: ${vehicle.ownerName}")
        if (vehicle.inspectionExpiryMillis > 0) appendLine("الفحص الفني القادم: ${formatArabicDate(vehicle.inspectionExpiryMillis)}")
        if (vehicle.notes.isNotEmpty()) appendLine("ملاحظات: ${vehicle.notes}")
        appendLine("\nتمت المشاركة عبر تطبيق رخصتي")
    }

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "رخصة ${vehicle.makeAndModel} - ${vehicle.plateNumber}")
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, "مشاركة بيانات الرخصة"))
}
