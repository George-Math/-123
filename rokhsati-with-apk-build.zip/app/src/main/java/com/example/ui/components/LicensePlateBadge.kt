package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LicensePlateBadge(
    plateNumber: String,
    vehicleType: String = "ملاكي",
    modifier: Modifier = Modifier,
    isLarge: Boolean = false
) {
    // Official plate header color based on vehicle type
    val headerColor = when (vehicleType) {
        "أجرة" -> Color(0xFFEA580C)      // Orange
        "نقل" -> Color(0xFFDC2626)       // Red
        "شرطة" -> Color(0xFF1E293B)      // Dark slate
        "حكومي" -> Color(0xFF0D9488)     // Teal
        else -> Color(0xFF2563EB)        // Classic Private car Blue
    }

    val plateShape = RoundedCornerShape(if (isLarge) 8.dp else 6.dp)

    Box(
        modifier = modifier
            .testTag("license_plate_badge")
            .shadow(if (isLarge) 4.dp else 2.dp, plateShape)
            .clip(plateShape)
            .border(
                width = if (isLarge) 2.dp else 1.5.dp,
                color = Color(0xFF334155),
                shape = plateShape
            )
            .background(Color.White)
            .width(if (isLarge) 190.dp else 140.dp)
    ) {
        Column {
            // Top country / category strip
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(headerColor)
                    .padding(vertical = if (isLarge) 3.dp else 2.dp, horizontal = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "مـصـر",
                        color = Color.White,
                        fontSize = if (isLarge) 11.sp else 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = vehicleType,
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = if (isLarge) 9.sp else 7.5.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "EGYPT",
                        color = Color.White,
                        fontSize = if (isLarge) 10.sp else 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Plate number area
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal = if (isLarge) 8.dp else 6.dp,
                        vertical = if (isLarge) 6.dp else 4.dp
                    ),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                // Realistic metallic bolt left
                Box(
                    modifier = Modifier
                        .size(if (isLarge) 5.dp else 4.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF94A3B8))
                )

                Spacer(modifier = Modifier.width(4.dp))

                Text(
                    text = plateNumber.ifEmpty { "س ر ج ٤٨١٩" },
                    color = Color(0xFF0F172A),
                    fontSize = if (isLarge) 17.sp else 13.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(4.dp))

                // Realistic metallic bolt right
                Box(
                    modifier = Modifier
                        .size(if (isLarge) 5.dp else 4.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF94A3B8))
                )
            }
        }
    }
}
