package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.AppUser
import com.example.data.model.LicenseStatus
import com.example.data.model.UserRole
import com.example.data.model.VehicleLicense
import com.example.data.repository.UserRepository
import com.example.data.repository.VehicleRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

enum class VehicleFilter(val label: String) {
    ALL("الكل"),
    VALID("سارية"),
    EXPIRING_SOON("تنتهي قريباً"),
    EXPIRED("منتهية")
}

enum class VehicleSort(val label: String) {
    EXPIRY_SOONEST("الأقرب انتهاءً"),
    EXPIRY_LATEST("الأبعد انتهاءً"),
    NAME("الموديل (أ - ي)"),
    NEWEST_MODEL("سنة الصنع (الأحدث)")
}

sealed class Screen {
    object Login : Screen()
    object Home : Screen()
    data class Detail(val vehicleId: Long) : Screen()
    data class AddEdit(val vehicleId: Long? = null) : Screen()
    object Analytics : Screen()
    object AdminUsers : Screen()
}

data class VehicleStats(
    val totalCount: Int = 0,
    val validCount: Int = 0,
    val expiringSoonCount: Int = 0,
    val expiredCount: Int = 0,
    val totalRenewalCost: Double = 0.0
)

class VehicleViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: VehicleRepository
    private val userRepository: UserRepository

    val currentScreen = MutableStateFlow<Screen>(Screen.Login)
    val currentUser = MutableStateFlow<AppUser?>(null)

    val filter = MutableStateFlow(VehicleFilter.ALL)
    val sortOrder = MutableStateFlow(VehicleSort.EXPIRY_SOONEST)
    val searchQuery = MutableStateFlow("")

    val allVehicles: StateFlow<List<VehicleLicense>>
    val allUsers: StateFlow<List<AppUser>>

    val filteredVehicles: StateFlow<List<VehicleLicense>>
    val stats: StateFlow<VehicleStats>

    init {
        val database = AppDatabase.getInstance(application)
        repository = VehicleRepository(database.vehicleDao())
        userRepository = UserRepository(database.userDao())

        viewModelScope.launch {
            userRepository.seedDefaults()
        }

        allUsers = userRepository.allUsers.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        // Clear any old sample data if present so the app starts completely empty as requested
        val prefs = application.getSharedPreferences("app_settings", Context.MODE_PRIVATE)
        val hasClearedInitialSamples = prefs.getBoolean("has_cleared_initial_samples_v1", false)
        if (!hasClearedInitialSamples) {
            viewModelScope.launch {
                repository.clearAll()
                prefs.edit().putBoolean("has_cleared_initial_samples_v1", true).apply()
            }
        }

        allVehicles = repository.allVehicles.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        stats = allVehicles.combine(MutableStateFlow(Unit)) { list, _ ->
            val now = System.currentTimeMillis()
            var valid = 0
            var expiring = 0
            var expired = 0
            var cost = 0.0

            for (v in list) {
                when (v.getLicenseStatus(now)) {
                    LicenseStatus.VALID -> valid++
                    LicenseStatus.EXPIRING_SOON -> expiring++
                    LicenseStatus.EXPIRED -> expired++
                }
                cost += v.estimatedRenewalCost
            }

            VehicleStats(
                totalCount = list.size,
                validCount = valid,
                expiringSoonCount = expiring,
                expiredCount = expired,
                totalRenewalCost = cost
            )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = VehicleStats()
        )

        filteredVehicles = combine(
            allVehicles,
            filter,
            sortOrder,
            searchQuery
        ) { vehicles, currentFilter, currentSort, query ->
            val now = System.currentTimeMillis()
            val trimmedQuery = query.trim().lowercase()

            val matchingQuery = if (trimmedQuery.isEmpty()) {
                vehicles
            } else {
                vehicles.filter { v ->
                    v.vehicleCode.lowercase().contains(trimmedQuery) ||
                    v.makeAndModel.lowercase().contains(trimmedQuery) ||
                    v.plateNumber.lowercase().contains(trimmedQuery) ||
                    v.driverName.lowercase().contains(trimmedQuery) ||
                    v.trafficDepartment.lowercase().contains(trimmedQuery) ||
                    v.ownerName.lowercase().contains(trimmedQuery) ||
                    v.chassisNumber.lowercase().contains(trimmedQuery)
                }
            }

            val filteredByStatus = when (currentFilter) {
                VehicleFilter.ALL -> matchingQuery
                VehicleFilter.VALID -> matchingQuery.filter { it.getLicenseStatus(now) == LicenseStatus.VALID }
                VehicleFilter.EXPIRING_SOON -> matchingQuery.filter { it.getLicenseStatus(now) == LicenseStatus.EXPIRING_SOON }
                VehicleFilter.EXPIRED -> matchingQuery.filter { it.getLicenseStatus(now) == LicenseStatus.EXPIRED }
            }

            when (currentSort) {
                VehicleSort.EXPIRY_SOONEST -> filteredByStatus.sortedBy { it.licenseExpiryDateMillis }
                VehicleSort.EXPIRY_LATEST -> filteredByStatus.sortedByDescending { it.licenseExpiryDateMillis }
                VehicleSort.NAME -> filteredByStatus.sortedBy { it.makeAndModel }
                VehicleSort.NEWEST_MODEL -> filteredByStatus.sortedByDescending { it.manufactureYear }
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun navigateTo(screen: Screen) {
        currentScreen.value = screen
    }

    fun navigateBack() {
        currentScreen.value = Screen.Home
    }

    fun setFilter(newFilter: VehicleFilter) {
        filter.value = newFilter
    }

    fun setSort(newSort: VehicleSort) {
        sortOrder.value = newSort
    }

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun saveVehicle(vehicle: VehicleLicense, onSaved: () -> Unit = {}) {
        viewModelScope.launch {
            if (vehicle.id == 0L) {
                repository.insertVehicle(vehicle)
            } else {
                repository.updateVehicle(vehicle)
            }
            onSaved()
            currentScreen.value = Screen.Home
        }
    }

    fun deleteVehicle(id: Long) {
        viewModelScope.launch {
            repository.deleteVehicleById(id)
            if (currentScreen.value is Screen.Detail) {
                currentScreen.value = Screen.Home
            }
        }
    }

    /**
     * Fast renew action by extending the current expiry date or extending from now if already expired.
     */
    fun quickRenew(vehicle: VehicleLicense, additionalYears: Int) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val baseTime = if (vehicle.licenseExpiryDateMillis < now) now else vehicle.licenseExpiryDateMillis
            val addedMillis = TimeUnit.DAYS.toMillis(365L * additionalYears)
            val updated = vehicle.copy(
                licenseExpiryDateMillis = baseTime + addedMillis,
                licenseIssueDateMillis = now
            )
            repository.updateVehicle(updated)
        }
    }

    fun clearAllVehicles() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }

    // --- Authentication & User Management ---

    fun loginUser(username: String, password: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val user = userRepository.authenticateUser(username, password)
            if (user != null) {
                currentUser.value = user
                currentScreen.value = Screen.Home
                onResult(true, null)
            } else {
                onResult(false, "اسم المستخدم أو كلمة المرور غير صحيحة")
            }
        }
    }

    fun loginAdmin(username: String, password: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val adminUser = userRepository.authenticateAdmin(username, password)
            if (adminUser != null) {
                currentUser.value = adminUser
                currentScreen.value = Screen.AdminUsers
                onResult(true, null)
            } else {
                onResult(false, "بيانات دخول المسئول غير صحيحة")
            }
        }
    }

    fun addNewUser(username: String, password: String, displayName: String = "", onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val newUser = AppUser(
                username = username.trim(),
                password = password.trim(),
                role = UserRole.USER,
                displayName = displayName.trim().ifEmpty { "مستخدم: ${username.trim()}" },
                createdAtMillis = System.currentTimeMillis()
            )
            val result = userRepository.addUser(newUser)
            if (result.isSuccess) {
                onResult(true, null)
            } else {
                onResult(false, result.exceptionOrNull()?.message ?: "فشل إضافة المستخدم")
            }
        }
    }

    fun deleteUser(username: String) {
        viewModelScope.launch {
            userRepository.deleteUser(username)
        }
    }

    fun logout() {
        currentUser.value = null
        currentScreen.value = Screen.Login
    }
}
