package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LicenseStatus
import com.example.ui.theme.StatusExpired
import com.example.ui.theme.StatusExpiredContainer
import com.example.ui.theme.StatusValid
import com.example.ui.theme.StatusValidContainer
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningContainer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

@Composable
fun CountdownBadge(
    expiryDateMillis: Long,
    modifier: Modifier = Modifier,
    isCompact: Boolean = false
) {
    val now = System.currentTimeMillis()
    val diffMillis = expiryDateMillis - now
    val daysRemaining = (diffMillis / (1000 * 60 * 60 * 24)).toInt()

    val status = when {
        daysRemaining < 0 -> LicenseStatus.EXPIRED
        daysRemaining <= 30 -> LicenseStatus.EXPIRING_SOON
        else -> LicenseStatus.VALID
    }

    val (bgColor, textColor, icon) = when (status) {
        LicenseStatus.VALID -> Triple(StatusValidContainer, StatusValid, Icons.Default.CheckCircle)
        LicenseStatus.EXPIRING_SOON -> Triple(StatusWarningContainer, StatusWarning, Icons.Default.Warning)
        LicenseStatus.EXPIRED -> Triple(StatusExpiredContainer, StatusExpired, Icons.Default.Error)
    }

    val statusText = when {
        daysRemaining < 0 -> {
            val daysAgo = abs(daysRemaining)
            if (daysAgo == 1) "منتهية منذ يوم" else "منتهية منذ $daysAgo يوماً"
        }
        daysRemaining == 0 -> "تنتهي اليوم!"
        daysRemaining == 1 -> "تنتهي غداً!"
        daysRemaining in 2..10 -> "باقي $daysRemaining أيام"
        daysRemaining in 11..30 -> "باقي $daysRemaining يوماً"
        daysRemaining in 31..60 -> "باقي شهر"
        daysRemaining in 61..90 -> "باقي شهرين"
        daysRemaining in 91..365 -> "باقي ${daysRemaining / 30} أشهر"
        else -> {
            val years = daysRemaining / 365
            val months = (daysRemaining % 365) / 30
            if (months > 0) "باقي $years سنة و $months أشهر" else "باقي $years سنة"
        }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .padding(
                horizontal = if (isCompact) 8.dp else 12.dp,
                vertical = if (isCompact) 4.dp else 6.dp
            )
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(if (isCompact) 14.dp else 16.dp)
            )

            Spacer(modifier = Modifier.width(6.dp))

            Text(
                text = statusText,
                color = textColor,
                fontSize = if (isCompact) 11.sp else 12.5.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

fun formatArabicDate(millis: Long): String {
    if (millis <= 0) return "غير محدد"
    val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
    return sdf.format(Date(millis))
}
