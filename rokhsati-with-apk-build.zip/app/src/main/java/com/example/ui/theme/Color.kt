package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Automotive Palette
val PrimaryNavy = Color(0xFF1E3A8A)
val PrimaryBlue = Color(0xFF2563EB)
val PrimaryLightBlue = Color(0xFF60A5FA)

val SecondaryGold = Color(0xFFD97706)
val SecondaryLightGold = Color(0xFFFBBF24)

val AccentCyan = Color(0xFF0284C7)

// Status Colors
val StatusValid = Color(0xFF059669)
val StatusValidContainer = Color(0xFFD1FAE5)
val StatusWarning = Color(0xFFD97706)
val StatusWarningContainer = Color(0xFFFEF3C7)
val StatusExpired = Color(0xFFDC2626)
val StatusExpiredContainer = Color(0xFFFEE2E2)

// Dark Theme Colors
val DarkBackground = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF121A2C)
val DarkSurfaceCard = Color(0xFF1B253B)
val DarkSurfaceBorder = Color(0xFF2A3852)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceCard = Color(0xFFF1F5F9)
val LightSurfaceBorder = Color(0xFFE2E8F0)
