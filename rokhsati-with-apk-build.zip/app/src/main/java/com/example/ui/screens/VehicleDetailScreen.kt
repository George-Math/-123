package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.DriveEta
import com.example.ui.components.FullScreenImageViewer
import java.io.File
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Update
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.VehicleLicense
import com.example.ui.components.CountdownBadge
import com.example.ui.components.LicensePhotoCard
import com.example.ui.components.LicensePlateBadge
import com.example.ui.components.RenewalProcedureSection
import com.example.ui.components.formatArabicDate
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.VehicleViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VehicleDetailScreen(
    vehicleId: Long,
    viewModel: VehicleViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val context = LocalContext.current
    val vehicles by viewModel.allVehicles.collectAsStateWithLifecycle()
    val vehicle = vehicles.find { it.id == vehicleId }

    var showDeleteConfirm by remember { mutableStateOf(false) }
    var viewingDocPath by remember { mutableStateOf<String?>(null) }
    var viewingDocTitle by remember { mutableStateOf("") }

    if (vehicle == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("المركبة غير موجودة أو تم حذفها")
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = { viewModel.navigateBack() }) {
                    Text("العودة للرئيسية")
                }
            }
        }
        return
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "تفاصيل الرخصة",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleLarge
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateBack() },
                        modifier = Modifier.testTag("detail_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "الرجوع"
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { shareVehicleSummary(context, vehicle) }) {
                        Icon(Icons.Default.Share, contentDescription = "مشاركة")
                    }
                    IconButton(onClick = { viewModel.navigateTo(Screen.AddEdit(vehicle.id)) }) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل")
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "حذف",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Digital Registration Card (بطاقة رخصة التسيير الرقمية)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(6.dp, RoundedCornerShape(20.dp)),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    // Header: Official Emblem & License Card title
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "جمهورية مصر العربية - وزارة الداخلية",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "رخصة تسيير مركبة إلكترونية",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Gold emblem seal
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.secondaryContainer)
                                .border(1.5.dp, MaterialTheme.colorScheme.secondary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.DirectionsCar,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Plate representation centered
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        LicensePlateBadge(
                            plateNumber = vehicle.plateNumber,
                            vehicleType = vehicle.vehicleType,
                            isLarge = true
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Vehicle Main Info
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = vehicle.makeAndModel,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                if (vehicle.vehicleCode.isNotEmpty()) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer)
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = "كود: ${vehicle.vehicleCode}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.5.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                            }
                            Text(
                                text = "موديل ${vehicle.manufactureYear} • ${vehicle.vehicleType} • ${vehicle.colorName}" +
                                    if (vehicle.isRefrigeratedTruck) " • تبريد/تلاجة" else "",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        CountdownBadge(expiryDateMillis = vehicle.licenseExpiryDateMillis)
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                    Spacer(modifier = Modifier.height(14.dp))

                    // Expiry Highlight Row
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "تاريخ انتهاء الرخصة",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = formatArabicDate(vehicle.licenseExpiryDateMillis),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }

                            if (vehicle.licenseIssueDateMillis > 0) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "تاريخ الإصدار",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = formatArabicDate(vehicle.licenseIssueDateMillis),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 1. License Photo Card (صورة رخصة التسيير - حفظ محلي في الهاتف)
            LicensePhotoCard(
                imagePath = vehicle.licenseImagePath,
                onImageSelected = { path ->
                    viewModel.saveVehicle(vehicle.copy(licenseImagePath = path))
                    Toast.makeText(context, "تم حفظ صورة الرخصة بنجاح في ذاكرة الهاتف", Toast.LENGTH_SHORT).show()
                },
                onImageDeleted = {
                    viewModel.saveVehicle(vehicle.copy(licenseImagePath = null))
                    Toast.makeText(context, "تم حذف صورة الرخصة من الهاتف", Toast.LENGTH_SHORT).show()
                }
            )

            // 2. Renewal Procedure Section (إجراءات تجديد الرخصة - الخطوات الخمس والشهادات)
            RenewalProcedureSection(
                vehicle = vehicle,
                onUpdateVehicle = { updated ->
                    viewModel.saveVehicle(updated)
                }
            )

            // Technical Specifications (الشاسيه، المحرك، الفحص، التأمين)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "البيانات الفنية والإدارية والتأمينية",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Vehicle Code
                    if (vehicle.vehicleCode.isNotEmpty()) {
                        DetailRow(
                            icon = Icons.Default.DirectionsCar,
                            title = "كود السيارة الداخلي",
                            value = vehicle.vehicleCode
                        )
                    }

                    // Refrigerator truck info if applicable
                    if (vehicle.isRefrigeratedTruck) {
                        DetailRow(
                            icon = Icons.Default.AcUnit,
                            title = "تجهيز المركبة",
                            value = "نقل تبريد / تلاجة (يتطلب فحص وزارة الصحة)"
                        )
                    }

                    // Traffic Department & Governorate
                    DetailRow(
                        icon = Icons.Default.LocationOn,
                        title = "وحدة المرور والمحافظة",
                        value = listOf(vehicle.trafficDepartment, vehicle.governorate)
                            .filter { it.isNotEmpty() }
                            .joinToString(" - ")
                            .ifEmpty { "غير محدد" }
                    )

                    // Vehicle Insurance Number
                    DetailRow(
                        icon = Icons.Default.Security,
                        title = "الرقم التأميني للسيارة",
                        value = vehicle.vehicleInsuranceNumber.ifEmpty { "غير مسجل" }
                    )

                    // Driver Insurance Number
                    if (vehicle.driverInsuranceNumber.isNotEmpty()) {
                        DetailRow(
                            icon = Icons.Default.Person,
                            title = "الرقم التأميني للسائق",
                            value = vehicle.driverInsuranceNumber
                        )
                    }

                    // Chassis Number (VIN) with copy
                    DetailRowWithCopy(
                        context = context,
                        icon = Icons.Default.DirectionsCar,
                        title = "رقم الشاسيه (VIN)",
                        value = vehicle.chassisNumber.ifEmpty { "غير مسجل" }
                    )

                    // Motor Number with copy
                    DetailRowWithCopy(
                        context = context,
                        icon = Icons.Default.DirectionsCar,
                        title = "رقم المحرك (الماتور)",
                        value = vehicle.motorNumber.ifEmpty { "غير مسجل" }
                    )

                    // Periodic Technical Inspection
                    DetailRow(
                        icon = Icons.Default.Engineering,
                        title = "الفحص الفني الدوري القادم",
                        value = if (vehicle.inspectionExpiryMillis > 0)
                            formatArabicDate(vehicle.inspectionExpiryMillis)
                        else
                            "غير مسجل"
                    )

                    // Compulsory Insurance
                    DetailRow(
                        icon = Icons.Default.Security,
                        title = "تاريخ انتهاء التأمين الإجباري",
                        value = if (vehicle.insuranceExpiryMillis > 0)
                            formatArabicDate(vehicle.insuranceExpiryMillis)
                        else
                            "غير مسجل"
                    )

                    // Estimated Renewal Cost
                    if (vehicle.estimatedRenewalCost > 0) {
                        DetailRow(
                            icon = Icons.Default.Payments,
                            title = "رسوم التجديد والضريبة التقديرية",
                            value = "${vehicle.estimatedRenewalCost.toInt()} جنيه مصري"
                        )
                    }

                    // Owner details
                    if (vehicle.ownerName.isNotEmpty() || vehicle.ownerNationalId.isNotEmpty()) {
                        DetailRow(
                            icon = Icons.Default.Person,
                            title = "اسم المالك والرقم القومي",
                            value = "${vehicle.ownerName.ifEmpty { "غير مسجل" }} ${if (vehicle.ownerNationalId.isNotEmpty()) "(${vehicle.ownerNationalId})" else ""}"
                        )
                    }

                    // Notes
                    if (vehicle.notes.isNotEmpty()) {
                        Column {
                            Text(
                                text = "ملاحظات إضافية:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = vehicle.notes,
                                fontSize = 13.5.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(10.dp)
                            )
                        }
                    }
                }
            }

            // Linked Driver Card (بيانات السائق المرتبط بالمركبة ومستنداته)
            if (vehicle.hasAssignedDriver || vehicle.driverName.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "بيانات السائق المرتبط بالمركبة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        DetailRow(
                            icon = Icons.Default.Person,
                            title = "اسم السائق",
                            value = vehicle.driverName.ifEmpty { "غير مسجل" }
                        )

                        if (vehicle.driverInsuranceNumber.isNotEmpty()) {
                            DetailRow(
                                icon = Icons.Default.Security,
                                title = "الرقم التأميني للسائق",
                                value = vehicle.driverInsuranceNumber
                            )
                        }

                        // Driver National ID and License action buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (!vehicle.driverNationalIdImagePath.isNullOrEmpty() && File(vehicle.driverNationalIdImagePath).exists()) {
                                OutlinedButton(
                                    onClick = {
                                        viewingDocPath = vehicle.driverNationalIdImagePath
                                        viewingDocTitle = "بطاقة الرقم القومي للسائق"
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Badge, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("معاينة البطاقة", fontSize = 12.sp)
                                }
                            }

                            if (!vehicle.driverLicenseImagePath.isNullOrEmpty() && File(vehicle.driverLicenseImagePath).exists()) {
                                OutlinedButton(
                                    onClick = {
                                        viewingDocPath = vehicle.driverLicenseImagePath
                                        viewingDocTitle = "رخصة قيادة السائق"
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.DriveEta, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("معاينة الرخصة", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Bottom action buttons (Edit & Delete)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { viewModel.navigateTo(Screen.AddEdit(vehicle.id)) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تعديل البيانات")
                }

                OutlinedButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حذف السيارة")
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("تأكيد الحذف", fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من حذف ${vehicle.makeAndModel}؟") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteVehicle(vehicle.id)
                        showDeleteConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (!viewingDocPath.isNullOrEmpty()) {
        FullScreenImageViewer(
            imagePath = viewingDocPath!!,
            title = viewingDocTitle,
            onDismiss = { viewingDocPath = null }
        )
    }
}

@Composable
fun DetailRow(
    icon: ImageVector,
    title: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 11.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun DetailRowWithCopy(
    context: Context,
    icon: ImageVector,
    title: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 11.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        if (value.isNotEmpty() && value != "غير مسجل") {
            IconButton(
                onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText(title, value))
                    Toast.makeText(context, "تم نسخ $title", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "نسخ",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

