package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.activity.compose.BackHandler
import com.example.ui.screens.AddEditVehicleScreen
import com.example.ui.screens.AdminUsersScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.VehicleDetailScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.Screen
import com.example.ui.viewmodel.VehicleViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Ensure natural RTL layout direction for Arabic experience
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    CarLicenseApp()
                }
            }
        }
    }
}

@Composable
fun CarLicenseApp(
    viewModel: VehicleViewModel = viewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen_transition",
        modifier = Modifier.fillMaxSize()
    ) { screen ->
        when (screen) {
            is Screen.Login -> {
                LoginScreen(viewModel = viewModel)
            }
            is Screen.Home -> {
                HomeScreen(viewModel = viewModel)
            }
            is Screen.Detail -> {
                BackHandler { viewModel.navigateBack() }
                VehicleDetailScreen(
                    vehicleId = screen.vehicleId,
                    viewModel = viewModel
                )
            }
            is Screen.AddEdit -> {
                BackHandler { viewModel.navigateBack() }
                AddEditVehicleScreen(
                    vehicleId = screen.vehicleId,
                    viewModel = viewModel
                )
            }
            is Screen.Analytics -> {
                BackHandler { viewModel.navigateBack() }
                AnalyticsScreen(viewModel = viewModel)
            }
            is Screen.AdminUsers -> {
                BackHandler { viewModel.navigateTo(Screen.Home) }
                AdminUsersScreen(viewModel = viewModel)
            }
        }
    }
}
